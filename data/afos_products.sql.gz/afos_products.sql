copy products(data,pil,entered,source,wmo,bbb) from STDIN (FORMAT CSV);
"001 
FXUS63 KDMX 100904
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
404 AM CDT Wed Jul 10 2024

.KEY MESSAGES...

- Scattered thunderstorms today. Marginally severe storms 
  possible. A few funnel clouds also possible

- Quiet Thursday and Friday.

- Heat returns on Sunday with heat indicies in the 100-105 
  range over parts of the area.

&&

.DISCUSSION...
Issued at 401 AM CDT Wed Jul 10 2024

The remnants of Beryl have are now near the southern tip of Lake 
Michigan with the last impacts over Iowa now are just some lingering 
clouds over the far eastern portion of the state. Another system 
with a robust PV anomaly consisting of a short wave cluster, is 
moving southeast through western Minnesota and eastern South Dakota 
with showers and a few thunderstorms descending south/southeast 
towards northwest Iowa. This system will continue to move into and 
across Iowa today and will be accompanied by attendant thunderstorm 
chances. A few features of note today. Convective temperatures are 
relatively low and in the upper 70s to low 80s in large part due to 
cooler temperatures a loft. These temperatures should be well within 
reach given that the mid level clouds do not fill in more than what 
has already occurred. This means that convection should be easily 
triggered given the kinematic forcing passing through. A few 
landspout funnels are possible today with a couple slow moving 
boundaries with little flow near it along with good stretching 
potential and surface vorticity in vicinity of the boundary. One 
boundary should be over northeast to north central Iowa this 
afternoon. That region will be a very low deep layer shear area 
where the potential for any organized activity is low but it may be 
the more favored region for any landspout funnels. The other 
boundary will be over central into west central/southwest Iowa. This 
region will have a bit more deep layer shear with some speed and 
directional shear available. Several CAMs are suggesting wind gusts 
and outflow with some of these storms. In addition, marginally 
severe hail could occur. The activity will linger into this evening 
then ending from north to south.

A couple relatively quiet days will follow to end the work week as 
high pressure ridge is the main weather influence. Thursday will 
have light winds with conditions becoming more breezy on Friday as 
the wind turns more southerly. A large upper level high will be 
entering the intermountain west this weekend and will lead to warm 
advection into the state. The warmest air will arrive Saturday night 
and into Sunday and as this occurs, expected an Elevated Mixed Layer 
to develop and become more pronounced. The NBM temperatures on 
Saturday are near the 75th percentile and for Sunday it is over the 
90th percentile with highs in the low to mid 90s. The NBMs track 
record through June has been way too optimistic in forecasting 
potential heat events and often has been several degrees too 
warm in the day 3-5 timeframe. This looks like another potential
period of the NBM being too warm. Dew points will be on the 
increase and in the upper 60s and 70s. The Iowa corn crop should
be entering peak evapotranspiration soon and given the 
relatively wet top soil, it should be efficient. This will pump 
a lot of water into the air which requires more energy to heat 
and thus likely leading to lower high temperatures. Finally, the
ECMWF and GFS ensemble highs for Sunday are 4-7 degrees cooler 
than deterministic MOS guidance for Sunday. Therefore, have 
cooled highs a bit for Sunday. It is still a potential day with 
near headline criteria heat indicies fueled by higher dew points
despite potential lower temperatures. Will the warmer weather 
persist into Monday is in question, pending on how quickly that 
western upper high and the associated westerlies into Iowa 
buckled as a system moves into the Midwest. Beyond that, upper 
ridging to the west could be setting up a ring of fire with 
storms running the lee side of the ridge, which often turns into
damaging wind events somewhere.

Finally of note is potential Canadian fire smoke moving into Iowa 
during periods of northwest flow aloft. Today is one day as a patch 
of smoke moves over Iowa. More chances of smoke filtered skies may 
arrive next week with that potential upper ridge to the west.

&&

.AVIATION /06Z TAFS THROUGH 06Z THURSDAY/...
Issued at 1029 PM CDT Tue Jul 9 2024

VFR conditions prevail across the area. No aviation impacts
forecast until scattered showers and storms move into the area
by late Wednesday morning and afternoon. Have included mention 
of VFR shra with vcts to cover the most likely timing of 
activity at each respective forecast terminal. The extent of the
categorical impacts is still somewhat uncertain. Cigs likely 
remain VFR, however brief MVFR or lower visby is possible at 
times if heavier downpours are observed.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Donavon
AVIATION...Martin
",AFDDMX,2024-07-10 04:04:00-05,KDMX,FXUS63,
"121 
FXUS63 KDMX 101134
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
634 AM CDT Wed Jul 10 2024

 ...Updated for the 12z Aviation Discussion...

.KEY MESSAGES...

- Scattered thunderstorms today. Marginally severe storms 
  possible. A few funnel clouds also possible

- Quiet Thursday and Friday.

- Heat returns on Sunday with heat indicies in the 100-105 
  range over parts of the area.

&&

.DISCUSSION...
Issued at 401 AM CDT Wed Jul 10 2024

The remnants of Beryl have are now near the southern tip of Lake 
Michigan with the last impacts over Iowa now are just some lingering 
clouds over the far eastern portion of the state. Another system 
with a robust PV anomaly consisting of a short wave cluster, is 
moving southeast through western Minnesota and eastern South Dakota 
with showers and a few thunderstorms descending south/southeast 
towards northwest Iowa. This system will continue to move into and 
across Iowa today and will be accompanied by attendant thunderstorm 
chances. A few features of note today. Convective temperatures are 
relatively low and in the upper 70s to low 80s in large part due to 
cooler temperatures a loft. These temperatures should be well within 
reach given that the mid level clouds do not fill in more than what 
has already occurred. This means that convection should be easily 
triggered given the kinematic forcing passing through. A few 
landspout funnels are possible today with a couple slow moving 
boundaries with little flow near it along with good stretching 
potential and surface vorticity in vicinity of the boundary. One 
boundary should be over northeast to north central Iowa this 
afternoon. That region will be a very low deep layer shear area 
where the potential for any organized activity is low but it may be 
the more favored region for any landspout funnels. The other 
boundary will be over central into west central/southwest Iowa. This 
region will have a bit more deep layer shear with some speed and 
directional shear available. Several CAMs are suggesting wind gusts 
and outflow with some of these storms. In addition, marginally 
severe hail could occur. The activity will linger into this evening 
then ending from north to south.

A couple relatively quiet days will follow to end the work week as 
high pressure ridge is the main weather influence. Thursday will 
have light winds with conditions becoming more breezy on Friday as 
the wind turns more southerly. A large upper level high will be 
entering the intermountain west this weekend and will lead to warm 
advection into the state. The warmest air will arrive Saturday night 
and into Sunday and as this occurs, expected an Elevated Mixed Layer 
to develop and become more pronounced. The NBM temperatures on 
Saturday are near the 75th percentile and for Sunday it is over the 
90th percentile with highs in the low to mid 90s. The NBMs track 
record through June has been way too optimistic in forecasting 
potential heat events and often has been several degrees too 
warm in the day 3-5 timeframe. This looks like another potential
period of the NBM being too warm. Dew points will be on the 
increase and in the upper 60s and 70s. The Iowa corn crop should
be entering peak evapotranspiration soon and given the 
relatively wet top soil, it should be efficient. This will pump 
a lot of water into the air which requires more energy to heat 
and thus likely leading to lower high temperatures. Finally, the
ECMWF and GFS ensemble highs for Sunday are 4-7 degrees cooler 
than deterministic MOS guidance for Sunday. Therefore, have 
cooled highs a bit for Sunday. It is still a potential day with 
near headline criteria heat indicies fueled by higher dew points
despite potential lower temperatures. Will the warmer weather 
persist into Monday is in question, pending on how quickly that 
western upper high and the associated westerlies into Iowa 
buckled as a system moves into the Midwest. Beyond that, upper 
ridging to the west could be setting up a ring of fire with 
storms running the lee side of the ridge, which often turns into
damaging wind events somewhere.

Finally of note is potential Canadian fire smoke moving into Iowa 
during periods of northwest flow aloft. Today is one day as a patch 
of smoke moves over Iowa. More chances of smoke filtered skies may 
arrive next week with that potential upper ridge to the west.

&&

.AVIATION /12Z TAFS THROUGH 12Z THURSDAY/...
Issued at 631 AM CDT Wed Jul 10 2024

Scattered showers and thunderstorms are ongoing to start the
period. The highest chances will be at KFOD/KDSM/KMCW through
15z. Cigs should remain VFR but vsbys may drop to 5sm or below
in rain. The precipitation should diminish late morning and
early afternoon before redeveloping. Most sites should be clear
of the precipitation by 00z or shortly after. The wind will
remain light today gradually turning from west to north then
slightly northeast. There is a chance for fog later tonight but
confidence at this time is low enough to not include in this
forecast.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Donavon
AVIATION...Donavon
",AFDDMX,2024-07-10 06:34:00-05,KDMX,FXUS63,
"851 
FXUS63 KDMX 101742
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1242 PM CDT Wed Jul 10 2024

 ...Updated for the 18z Aviation Discussion...

.KEY MESSAGES...

- Scattered thunderstorms today. Marginally severe storms 
  possible. A few funnel clouds also possible

- Quiet Thursday and Friday.

- Heat returns on Sunday with heat indicies in the 100-105 
  range over parts of the area.

&&

.DISCUSSION...
Issued at 401 AM CDT Wed Jul 10 2024

The remnants of Beryl have are now near the southern tip of Lake 
Michigan with the last impacts over Iowa now are just some lingering 
clouds over the far eastern portion of the state. Another system 
with a robust PV anomaly consisting of a short wave cluster, is 
moving southeast through western Minnesota and eastern South Dakota 
with showers and a few thunderstorms descending south/southeast 
towards northwest Iowa. This system will continue to move into and 
across Iowa today and will be accompanied by attendant thunderstorm 
chances. A few features of note today. Convective temperatures are 
relatively low and in the upper 70s to low 80s in large part due to 
cooler temperatures a loft. These temperatures should be well within 
reach given that the mid level clouds do not fill in more than what 
has already occurred. This means that convection should be easily 
triggered given the kinematic forcing passing through. A few 
landspout funnels are possible today with a couple slow moving 
boundaries with little flow near it along with good stretching 
potential and surface vorticity in vicinity of the boundary. One 
boundary should be over northeast to north central Iowa this 
afternoon. That region will be a very low deep layer shear area 
where the potential for any organized activity is low but it may be 
the more favored region for any landspout funnels. The other 
boundary will be over central into west central/southwest Iowa. This 
region will have a bit more deep layer shear with some speed and 
directional shear available. Several CAMs are suggesting wind gusts 
and outflow with some of these storms. In addition, marginally 
severe hail could occur. The activity will linger into this evening 
then ending from north to south.

A couple relatively quiet days will follow to end the work week as 
high pressure ridge is the main weather influence. Thursday will 
have light winds with conditions becoming more breezy on Friday as 
the wind turns more southerly. A large upper level high will be 
entering the intermountain west this weekend and will lead to warm 
advection into the state. The warmest air will arrive Saturday night 
and into Sunday and as this occurs, expected an Elevated Mixed Layer 
to develop and become more pronounced. The NBM temperatures on 
Saturday are near the 75th percentile and for Sunday it is over the 
90th percentile with highs in the low to mid 90s. The NBMs track 
record through June has been way too optimistic in forecasting 
potential heat events and often has been several degrees too 
warm in the day 3-5 timeframe. This looks like another potential
period of the NBM being too warm. Dew points will be on the 
increase and in the upper 60s and 70s. The Iowa corn crop should
be entering peak evapotranspiration soon and given the 
relatively wet top soil, it should be efficient. This will pump 
a lot of water into the air which requires more energy to heat 
and thus likely leading to lower high temperatures. Finally, the
ECMWF and GFS ensemble highs for Sunday are 4-7 degrees cooler 
than deterministic MOS guidance for Sunday. Therefore, have 
cooled highs a bit for Sunday. It is still a potential day with 
near headline criteria heat indicies fueled by higher dew points
despite potential lower temperatures. Will the warmer weather 
persist into Monday is in question, pending on how quickly that 
western upper high and the associated westerlies into Iowa 
buckled as a system moves into the Midwest. Beyond that, upper 
ridging to the west could be setting up a ring of fire with 
storms running the lee side of the ridge, which often turns into
damaging wind events somewhere.

Finally of note is potential Canadian fire smoke moving into Iowa 
during periods of northwest flow aloft. Today is one day as a patch 
of smoke moves over Iowa. More chances of smoke filtered skies may 
arrive next week with that potential upper ridge to the west.

&&

.AVIATION /18Z TAFS THROUGH 18Z THURSDAY/...
Issued at 1241 PM CDT Wed Jul 10 2024

Scattered showers/storms over the area through about 01z with
higher chances at ALO/FOD/DSM/OTM. Upper level wave tracking
south with sfc trough expected to move south of the region aft
06z. Main challenge timing/coverage but some storms will lower
cigs to MVFR with vsby 2-5sm possible with brief heavy
downpours. Patchy fog also expected 10-13z. Aft 13z, remainder 
of period fairly benign. /rev


&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Donavon
AVIATION...REV
",AFDDMX,2024-07-10 12:42:00-05,KDMX,FXUS63,
"007 
FXUS63 KDMX 101923
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
223 PM CDT Wed Jul 10 2024

.KEY MESSAGES...

- Scattered storms today; with some strong to severer storms
  this afternoon and evening. 
- Seasonal Temps Through Friday; approaching 90 Saturday
- Heating up into the 90s by Sunday and Monday with heat indices
  over 100F during the period. Late in the period, cooler back
  down.

&&

.DISCUSSION...
Issued at 222 PM CDT Wed Jul 10 2024

.Short Term /Tonight through Thursday Night/...

Confidence Short Term:  Medium to High

In between pattern changes with continued warm and humid conditions 
and scattered showers/storms today into tonight with lesser chances 
on Thursday/Friday but increasing again Friday night. Old Beryl, now 
a plain ole synoptic low, is currently heading into southern lower 
Michigan this morning at 12z. A weak trough stretches back to the 
west from the system and is located along the Iowa Minnesota border. 
As the remnants of Beryl moved northeast, it phased slightly with a 
preexisting upper level system and brought lower heights into Iowa 
overnight. This has helped to expand the area of showers/weak 
thunderstorms across the region this morning. While widely scattered 
storms continue in central Iowa at 1330z, a more widespread area is 
located along the main/upper troughs in southern Minnesota. The 
trough will likely set up shop over central to southern Iowa by late 
afternoon/evening. With sufficient instability, and a small area of 
shear in southwest Iowa, a few more organized storms may occur into 
the evening with wind or hail, or a few funnels. We are now 
outlooked for a slight risk in the far southwest for larger hail and 
perhaps a bit of wind. Otherwise, the weak wind shift and 
instability over areas along and south of I80 may lead to a few 
funnel clouds this afternoon. The other area to watch will be over 
northern to northeast Iowa where NST parameters ramp up this 
afternoon into the early evening hours. Though soundings are not 
particularly moist, we do have H850 dewpoints of 10 to 12C over the 
region along the approaching trough.  PWATs are running 1 to 1.5 
inches with warm cloud depths around 10kft. Upstream qpf amounts in 
southern MN overnight and earlier today have been in the 1 to 2 inch 
range, mainly due to the slow moving storms and the upper level PV 
max. Though spotty, some random 1 to 1.5+ inch amounts may occur 
this afternoon into the evening hours. Overnight tonight, the system 
will pull into southern Iowa/northern Missouri with some lingering 
showers early southeast. With nearly calm winds by morning, some 
patchy fog is expected and especially in valley areas. Tomorrow we 
remain with a similar airmass, but less forcing. A few afternoon 
showers/iso storms may again occur mainly east of I35 during the 
afternoon hours. By nightfall, light south southeast flow returns to 
the region as lee side troughing commences into the region. 
Temperatures and humidity levels will begin to increase as we move 
into the weekend. Lows tonight will fall into the lower 60s over the 
area with afternoon highs tomorrow in the lower to mid 80s. Tomorrow 
night, with increasing warm air advection, lows will fall only to 
the lower to mid 60s. 

.Long Term /Friday through Wednesday/...

Confidence: Medium to High

Friday will see some clouds increase by late afternoon as a warm 
front approaches late in the day. With afternoon H850 temperatures 
warming up to 16C northeast to 21C southwest. Deterministic models 
are forecasting a 25 to 35kt low level jet overnight Friday night 
into early Saturday morning. Efficient rainfall parameters are again 
ramping up overnight. Depending on how quickly storms can ramp up 
overnight, brief heavy rainfall may occur with some of the scattered 
thunderstorms. Current blended output puts rainfall chances at 
around 20 to 30%, though we may need to raise those values. Friday 
night will see warmer overnight mins with readings with upper 60s to 
lower 70s. Over the weekend, we will again be saddled with a humid 
airmass with either weak impulses or warm air advection processes 
aiding in some lift. The current forecast calls for the H700 cap to 
be building toward eastern Iowa by afternoon. This should keep rain 
chances toward a minimum over our area. For the weekend, the hot 
dome over the southwest will build east for Saturday and Sunday. 
Highs Saturday will already reach the upper 80s to lower 90s. By 
Sunday, our H850 temperatures warm to 20 to 25C with increased 
mixing. Sunday appears to be the hotter of the two days with H850 
temps peaking at 25 to 28C. This will lead to highs in the mid 90s 
during the afternoon. By Monday, some cloud cover may hold temps 
back a degree or so, but overall the medium range models suggest 
that a boundary north of the forecast area will drop south 
later Monday night into early Tuesday, when temperatures will 
cool further. With increasing temps over the weekend and 
dewpoints on the way up, heat indices will be up above 100 for 
Sunday and possibly into Monday. There's a fair amount of 
uncertainty from Tuesday into Wednesday with regard to rain 
chances, though as the front drops south, chances for a few 
storms should go up as the H700 cap cools. We round off the 
extended with highs falling back to the lower to mid 80s by 
Wednesday central to south with upper 70s over the north.

&&

.AVIATION /18Z TAFS THROUGH 18Z THURSDAY/...
Issued at 1241 PM CDT Wed Jul 10 2024

Scattered showers/storms over the area through about 01z with
higher chances at ALO/FOD/DSM/OTM. Upper level wave tracking
south with sfc trough expected to move south of the region aft
06z. Main challenge timing/coverage but some storms will lower
cigs to MVFR with vsby 2-5sm possible with brief heavy
downpours. Patchy fog also expected 10-13z. Aft 13z, remainder 
of period fairly benign. /rev

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...REV
AVIATION...REV
",AFDDMX,2024-07-10 14:23:00-05,KDMX,FXUS63,
"064 
FXUS63 KDMX 102338
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
638 PM CDT Wed Jul 10 2024

 ...Updated for the 00z Aviation Discussion...

.KEY MESSAGES...

- Scattered storms today; with some strong to severer storms
  this afternoon and evening. 
- Seasonal Temps Through Friday; approaching 90 Saturday
- Heating up into the 90s by Sunday and Monday with heat indices
  over 100F during the period. Late in the period, cooler back
  down.

&&

.DISCUSSION...
Issued at 222 PM CDT Wed Jul 10 2024

.Short Term /Tonight through Thursday Night/...

Confidence Short Term:  Medium to High

In between pattern changes with continued warm and humid conditions 
and scattered showers/storms today into tonight with lesser chances 
on Thursday/Friday but increasing again Friday night. Old Beryl, now 
a plain ole synoptic low, is currently heading into southern lower 
Michigan this morning at 12z. A weak trough stretches back to the 
west from the system and is located along the Iowa Minnesota border. 
As the remnants of Beryl moved northeast, it phased slightly with a 
preexisting upper level system and brought lower heights into Iowa 
overnight. This has helped to expand the area of showers/weak 
thunderstorms across the region this morning. While widely scattered 
storms continue in central Iowa at 1330z, a more widespread area is 
located along the main/upper troughs in southern Minnesota. The 
trough will likely set up shop over central to southern Iowa by late 
afternoon/evening. With sufficient instability, and a small area of 
shear in southwest Iowa, a few more organized storms may occur into 
the evening with wind or hail, or a few funnels. We are now 
outlooked for a slight risk in the far southwest for larger hail and 
perhaps a bit of wind. Otherwise, the weak wind shift and 
instability over areas along and south of I80 may lead to a few 
funnel clouds this afternoon. The other area to watch will be over 
northern to northeast Iowa where NST parameters ramp up this 
afternoon into the early evening hours. Though soundings are not 
particularly moist, we do have H850 dewpoints of 10 to 12C over the 
region along the approaching trough.  PWATs are running 1 to 1.5 
inches with warm cloud depths around 10kft. Upstream qpf amounts in 
southern MN overnight and earlier today have been in the 1 to 2 inch 
range, mainly due to the slow moving storms and the upper level PV 
max. Though spotty, some random 1 to 1.5+ inch amounts may occur 
this afternoon into the evening hours. Overnight tonight, the system 
will pull into southern Iowa/northern Missouri with some lingering 
showers early southeast. With nearly calm winds by morning, some 
patchy fog is expected and especially in valley areas. Tomorrow we 
remain with a similar airmass, but less forcing. A few afternoon 
showers/iso storms may again occur mainly east of I35 during the 
afternoon hours. By nightfall, light south southeast flow returns to 
the region as lee side troughing commences into the region. 
Temperatures and humidity levels will begin to increase as we move 
into the weekend. Lows tonight will fall into the lower 60s over the 
area with afternoon highs tomorrow in the lower to mid 80s. Tomorrow 
night, with increasing warm air advection, lows will fall only to 
the lower to mid 60s. 

.Long Term /Friday through Wednesday/...

Confidence: Medium to High

Friday will see some clouds increase by late afternoon as a warm 
front approaches late in the day. With afternoon H850 temperatures 
warming up to 16C northeast to 21C southwest. Deterministic models 
are forecasting a 25 to 35kt low level jet overnight Friday night 
into early Saturday morning. Efficient rainfall parameters are again 
ramping up overnight. Depending on how quickly storms can ramp up 
overnight, brief heavy rainfall may occur with some of the scattered 
thunderstorms. Current blended output puts rainfall chances at 
around 20 to 30%, though we may need to raise those values. Friday 
night will see warmer overnight mins with readings with upper 60s to 
lower 70s. Over the weekend, we will again be saddled with a humid 
airmass with either weak impulses or warm air advection processes 
aiding in some lift. The current forecast calls for the H700 cap to 
be building toward eastern Iowa by afternoon. This should keep rain 
chances toward a minimum over our area. For the weekend, the hot 
dome over the southwest will build east for Saturday and Sunday. 
Highs Saturday will already reach the upper 80s to lower 90s. By 
Sunday, our H850 temperatures warm to 20 to 25C with increased 
mixing. Sunday appears to be the hotter of the two days with H850 
temps peaking at 25 to 28C. This will lead to highs in the mid 90s 
during the afternoon. By Monday, some cloud cover may hold temps 
back a degree or so, but overall the medium range models suggest 
that a boundary north of the forecast area will drop south 
later Monday night into early Tuesday, when temperatures will 
cool further. With increasing temps over the weekend and 
dewpoints on the way up, heat indices will be up above 100 for 
Sunday and possibly into Monday. There's a fair amount of 
uncertainty from Tuesday into Wednesday with regard to rain 
chances, though as the front drops south, chances for a few 
storms should go up as the H700 cap cools. We round off the 
extended with highs falling back to the lower to mid 80s by 
Wednesday central to south with upper 70s over the north.

&&

.AVIATION /00Z TAFS THROUGH 00Z FRIDAY/...
Issued at 638 PM CDT Wed Jul 10 2024

Scattered thunderstorms will continue across the area through 
the next few hours, with main impacts expected at
KMCW/KALO/KDSM. The rest of the evening should remain quiet. By
Thursday morning some patchy fog is possible, however confidence
is low in development so for now have only included at northern
sites KFOD/KMCW. Wind on Thursday will then gradually shift to
out of the east/southeast.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...REV
AVIATION...Hagenhoff
",AFDDMX,2024-07-10 18:38:00-05,KDMX,FXUS63,
"151 
FXUS63 KDMX 110348
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1048 PM CDT Wed Jul 10 2024

 ...Updated for the 06z Aviation Discussion...

.KEY MESSAGES...

- Scattered storms today; with some strong to severer storms
  this afternoon and evening. 
- Seasonal Temps Through Friday; approaching 90 Saturday
- Heating up into the 90s by Sunday and Monday with heat indices
  over 100F during the period. Late in the period, cooler back
  down.

&&

.DISCUSSION...
Issued at 222 PM CDT Wed Jul 10 2024

.Short Term /Tonight through Thursday Night/...

Confidence Short Term:  Medium to High

In between pattern changes with continued warm and humid conditions 
and scattered showers/storms today into tonight with lesser chances 
on Thursday/Friday but increasing again Friday night. Old Beryl, now 
a plain ole synoptic low, is currently heading into southern lower 
Michigan this morning at 12z. A weak trough stretches back to the 
west from the system and is located along the Iowa Minnesota border. 
As the remnants of Beryl moved northeast, it phased slightly with a 
preexisting upper level system and brought lower heights into Iowa 
overnight. This has helped to expand the area of showers/weak 
thunderstorms across the region this morning. While widely scattered 
storms continue in central Iowa at 1330z, a more widespread area is 
located along the main/upper troughs in southern Minnesota. The 
trough will likely set up shop over central to southern Iowa by late 
afternoon/evening. With sufficient instability, and a small area of 
shear in southwest Iowa, a few more organized storms may occur into 
the evening with wind or hail, or a few funnels. We are now 
outlooked for a slight risk in the far southwest for larger hail and 
perhaps a bit of wind. Otherwise, the weak wind shift and 
instability over areas along and south of I80 may lead to a few 
funnel clouds this afternoon. The other area to watch will be over 
northern to northeast Iowa where NST parameters ramp up this 
afternoon into the early evening hours. Though soundings are not 
particularly moist, we do have H850 dewpoints of 10 to 12C over the 
region along the approaching trough.  PWATs are running 1 to 1.5 
inches with warm cloud depths around 10kft. Upstream qpf amounts in 
southern MN overnight and earlier today have been in the 1 to 2 inch 
range, mainly due to the slow moving storms and the upper level PV 
max. Though spotty, some random 1 to 1.5+ inch amounts may occur 
this afternoon into the evening hours. Overnight tonight, the system 
will pull into southern Iowa/northern Missouri with some lingering 
showers early southeast. With nearly calm winds by morning, some 
patchy fog is expected and especially in valley areas. Tomorrow we 
remain with a similar airmass, but less forcing. A few afternoon 
showers/iso storms may again occur mainly east of I35 during the 
afternoon hours. By nightfall, light south southeast flow returns to 
the region as lee side troughing commences into the region. 
Temperatures and humidity levels will begin to increase as we move 
into the weekend. Lows tonight will fall into the lower 60s over the 
area with afternoon highs tomorrow in the lower to mid 80s. Tomorrow 
night, with increasing warm air advection, lows will fall only to 
the lower to mid 60s. 

.Long Term /Friday through Wednesday/...

Confidence: Medium to High

Friday will see some clouds increase by late afternoon as a warm 
front approaches late in the day. With afternoon H850 temperatures 
warming up to 16C northeast to 21C southwest. Deterministic models 
are forecasting a 25 to 35kt low level jet overnight Friday night 
into early Saturday morning. Efficient rainfall parameters are again 
ramping up overnight. Depending on how quickly storms can ramp up 
overnight, brief heavy rainfall may occur with some of the scattered 
thunderstorms. Current blended output puts rainfall chances at 
around 20 to 30%, though we may need to raise those values. Friday 
night will see warmer overnight mins with readings with upper 60s to 
lower 70s. Over the weekend, we will again be saddled with a humid 
airmass with either weak impulses or warm air advection processes 
aiding in some lift. The current forecast calls for the H700 cap to 
be building toward eastern Iowa by afternoon. This should keep rain 
chances toward a minimum over our area. For the weekend, the hot 
dome over the southwest will build east for Saturday and Sunday. 
Highs Saturday will already reach the upper 80s to lower 90s. By 
Sunday, our H850 temperatures warm to 20 to 25C with increased 
mixing. Sunday appears to be the hotter of the two days with H850 
temps peaking at 25 to 28C. This will lead to highs in the mid 90s 
during the afternoon. By Monday, some cloud cover may hold temps 
back a degree or so, but overall the medium range models suggest 
that a boundary north of the forecast area will drop south 
later Monday night into early Tuesday, when temperatures will 
cool further. With increasing temps over the weekend and 
dewpoints on the way up, heat indices will be up above 100 for 
Sunday and possibly into Monday. There's a fair amount of 
uncertainty from Tuesday into Wednesday with regard to rain 
chances, though as the front drops south, chances for a few 
storms should go up as the H700 cap cools. We round off the 
extended with highs falling back to the lower to mid 80s by 
Wednesday central to south with upper 70s over the north.

&&

.AVIATION /00Z TAFS THROUGH 00Z FRIDAY/...
Issued at 1048 PM CDT Wed Jul 10 2024

A few showers linger in eastern Iowa, otherwise activity has
ended across the area. Overnight patchy fog remain possible,
however data is split on where this will be impactful at TAF
sites. Have included MVFR mention at KMCW/KFOD where fog is more
likely. Amendments may be necessary as conditions change
through the early morning. Otherwise winds shift to out of the
east/southeast with VFR conditions to finish out the period.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...REV
AVIATION...Hagenhoff
",AFDDMX,2024-07-10 22:48:00-05,KDMX,FXUS63,
"291 
FXUS63 KDMX 110852
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
352 AM CDT Thu Jul 11 2024

.KEY MESSAGES...

- Pleasant summer day today with light winds.

- Heat arrives for this weekend. Heat index values near to above
  100 possible Saturday and Sunday afternoons. The heat may
  persist over central and southern Iowa on Monday.

&&

.DISCUSSION...
Issued at 346 AM CDT Thu Jul 11 2024

Upper level low pressure is over east central Iowa early this 
morning. A few showers and storms are still ongoing across parts of 
east central and into southeast Iowa in response to the system. The 
precipitation is co-located with the system's upper level cold core 
evident around 600 mb and higher. This activity will be diminishing 
over the next several hours as the upper level system begins to 
depart to the east. A few areas of fog have also developed early 
this morning  with the fog is located along and south of Highway 34 
over far southern Iowa and also over parts of far northwest Iowa. 
Additional expansion of the fog is possible this morning in areas 
with the clear skies. 

Otherwise for today, surface high pressure will control the weather 
with light winds today. Some shallow and flat cumulus development is 
possible by this afternoon though the cumulus over northeast Iowa 
could have more vertical extent than central Iowa though no 
precipitation is expected. Warm advection will begin to lift into 
southwest Iowa tonight but the moisture advection will be lagging 
and a very dry air mass will remain over much of Iowa and any 
precipitation should remain south into Missouri. The moisture 
advection will begin to pivot into Iowa on Friday but precipitation 
is not expected as it will take time for profiles to saturate and 
the Elevated Mixed Layer (EML) will become established which will 
cap off any surface based convection. 

The low level jet will tilt into southern Iowa Friday night and will 
bring some elevated instability to that part of the state. A few 
elevated storms are possible if enough saturation can occur aloft 
and near the forcing to release some of that instability. The EML is 
expected to become more pronounced on Saturday and Sunday as more 
warm advection aloft occurs and a portion of the thermal bubble to 
the west arrives. This brings the million dollar question that we 
have been discussing the past several days, how warm will it get 
this weekend? All points discussed during these past several days 
remain valid. One, the boundary layer should mix well below the EML 
but it is capped due to the EML somewhere below 850 mb. Two, surface 
dew points will be on the increase due to moisture advection and a 
very big second this time of year, we are entering peak 
evapotranspiration of Iowa crops. What impact will the mixing have 
on the dew points. The most like scenario is dew points will be in 
the low to mid 70s by mid afternoon. Three, the NBM temperatures 
remain near the 90th percentile or higher and are likely overdone. 
That said, the NBM spreads are fairly low and the 925 mb 
temperatures at 12z each morning are in the mid 20s C which would 
support a launch into the 90s by the afternoon. Finally, Four, does 
it matter meaning higher temperatures with lower dew points or lower 
temperatures with higher dew points will result in similar heat 
index values. Expecting heat index values of 95 to low 100s on 
Saturday and roughly 100 to 105 on Sunday. Heat will be the key 
messaging this forecast period.

A buckle in the western upper high is still on track sometime Monday 
or Monday night which will drop a boundary into the state. The exact 
timing will play a role on if the heat remains Monday. At this time, 
some relief into northern Iowa is expected but the heat may linger 
central and south. A more active period in the weather looks 
possible by mid next week as a stronger upper level system passes 
through the region.

&&

.AVIATION /06Z TAFS THROUGH 06Z FRIDAY/...
Issued at 1048 PM CDT Wed Jul 10 2024

A few showers linger in eastern Iowa, otherwise activity has
ended across the area. Overnight patchy fog remain possible,
however data is split on where this will be impactful at TAF
sites. Have included MVFR mention at KMCW/KFOD where fog is more
likely. Amendments may be necessary as conditions change
through the early morning. Otherwise winds shift to out of the
east/southeast with VFR conditions to finish out the period.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Donavon
AVIATION...Hagenhoff
",AFDDMX,2024-07-11 03:52:00-05,KDMX,FXUS63,
"018 
FXUS63 KDMX 111104
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
604 AM CDT Thu Jul 11 2024

 ...Updated for the 12z Aviation Discussion...

.KEY MESSAGES...

- Pleasant summer day today with light winds.

- Heat arrives for this weekend. Heat index values near to above
  100 possible Saturday and Sunday afternoons. The heat may
  persist over central and southern Iowa on Monday.

&&

.DISCUSSION...
Issued at 346 AM CDT Thu Jul 11 2024

Upper level low pressure is over east central Iowa early this 
morning. A few showers and storms are still ongoing across parts of 
east central and into southeast Iowa in response to the system. The 
precipitation is co-located with the system's upper level cold core 
evident around 600 mb and higher. This activity will be diminishing 
over the next several hours as the upper level system begins to 
depart to the east. A few areas of fog have also developed early 
this morning  with the fog is located along and south of Highway 34 
over far southern Iowa and also over parts of far northwest Iowa. 
Additional expansion of the fog is possible this morning in areas 
with the clear skies. 

Otherwise for today, surface high pressure will control the weather 
with light winds today. Some shallow and flat cumulus development is 
possible by this afternoon though the cumulus over northeast Iowa 
could have more vertical extent than central Iowa though no 
precipitation is expected. Warm advection will begin to lift into 
southwest Iowa tonight but the moisture advection will be lagging 
and a very dry air mass will remain over much of Iowa and any 
precipitation should remain south into Missouri. The moisture 
advection will begin to pivot into Iowa on Friday but precipitation 
is not expected as it will take time for profiles to saturate and 
the Elevated Mixed Layer (EML) will become established which will 
cap off any surface based convection. 

The low level jet will tilt into southern Iowa Friday night and will 
bring some elevated instability to that part of the state. A few 
elevated storms are possible if enough saturation can occur aloft 
and near the forcing to release some of that instability. The EML is 
expected to become more pronounced on Saturday and Sunday as more 
warm advection aloft occurs and a portion of the thermal bubble to 
the west arrives. This brings the million dollar question that we 
have been discussing the past several days, how warm will it get 
this weekend? All points discussed during these past several days 
remain valid. One, the boundary layer should mix well below the EML 
but it is capped due to the EML somewhere below 850 mb. Two, surface 
dew points will be on the increase due to moisture advection and a 
very big second this time of year, we are entering peak 
evapotranspiration of Iowa crops. What impact will the mixing have 
on the dew points. The most like scenario is dew points will be in 
the low to mid 70s by mid afternoon. Three, the NBM temperatures 
remain near the 90th percentile or higher and are likely overdone. 
That said, the NBM spreads are fairly low and the 925 mb 
temperatures at 12z each morning are in the mid 20s C which would 
support a launch into the 90s by the afternoon. Finally, Four, does 
it matter meaning higher temperatures with lower dew points or lower 
temperatures with higher dew points will result in similar heat 
index values. Expecting heat index values of 95 to low 100s on 
Saturday and roughly 100 to 105 on Sunday. Heat will be the key 
messaging this forecast period.

A buckle in the western upper high is still on track sometime Monday 
or Monday night which will drop a boundary into the state. The exact 
timing will play a role on if the heat remains Monday. At this time, 
some relief into northern Iowa is expected but the heat may linger 
central and south. A more active period in the weather looks 
possible by mid next week as a stronger upper level system passes 
through the region.

&&

.AVIATION /12Z TAFS THROUGH 12Z FRIDAY/...
Issued at 604 AM CDT Thu Jul 11 2024

Some fog in vicinity of KALO/KOTM early in the period will
diminish quickly. Cumulus development is likely today and could
become locally BKN. Cumulus bases could begin near 3 kft but
will rise through the afternoon to 4-5 kft. Fog could return
tonight but again confidence is low at any individual site. The
wind will be light and variable to north to begin the today then
gradually turning more east/southeast through the period.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Donavon
AVIATION...Donavon
",AFDDMX,2024-07-11 06:04:00-05,KDMX,FXUS63,
"449 
FXUS63 KDMX 111737
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1237 PM CDT Thu Jul 11 2024

 ...Updated for the 18z Aviation Discussion...

.KEY MESSAGES...

- Pleasant summer day today with light winds.

- Heat arrives for this weekend. Heat index values near to above
  100 possible Saturday and Sunday afternoons. The heat may
  persist over central and southern Iowa on Monday.

&&

.DISCUSSION...
Issued at 346 AM CDT Thu Jul 11 2024

Upper level low pressure is over east central Iowa early this 
morning. A few showers and storms are still ongoing across parts of 
east central and into southeast Iowa in response to the system. The 
precipitation is co-located with the system's upper level cold core 
evident around 600 mb and higher. This activity will be diminishing 
over the next several hours as the upper level system begins to 
depart to the east. A few areas of fog have also developed early 
this morning  with the fog is located along and south of Highway 34 
over far southern Iowa and also over parts of far northwest Iowa. 
Additional expansion of the fog is possible this morning in areas 
with the clear skies. 

Otherwise for today, surface high pressure will control the weather 
with light winds today. Some shallow and flat cumulus development is 
possible by this afternoon though the cumulus over northeast Iowa 
could have more vertical extent than central Iowa though no 
precipitation is expected. Warm advection will begin to lift into 
southwest Iowa tonight but the moisture advection will be lagging 
and a very dry air mass will remain over much of Iowa and any 
precipitation should remain south into Missouri. The moisture 
advection will begin to pivot into Iowa on Friday but precipitation 
is not expected as it will take time for profiles to saturate and 
the Elevated Mixed Layer (EML) will become established which will 
cap off any surface based convection. 

The low level jet will tilt into southern Iowa Friday night and will 
bring some elevated instability to that part of the state. A few 
elevated storms are possible if enough saturation can occur aloft 
and near the forcing to release some of that instability. The EML is 
expected to become more pronounced on Saturday and Sunday as more 
warm advection aloft occurs and a portion of the thermal bubble to 
the west arrives. This brings the million dollar question that we 
have been discussing the past several days, how warm will it get 
this weekend? All points discussed during these past several days 
remain valid. One, the boundary layer should mix well below the EML 
but it is capped due to the EML somewhere below 850 mb. Two, surface 
dew points will be on the increase due to moisture advection and a 
very big second this time of year, we are entering peak 
evapotranspiration of Iowa crops. What impact will the mixing have 
on the dew points. The most like scenario is dew points will be in 
the low to mid 70s by mid afternoon. Three, the NBM temperatures 
remain near the 90th percentile or higher and are likely overdone. 
That said, the NBM spreads are fairly low and the 925 mb 
temperatures at 12z each morning are in the mid 20s C which would 
support a launch into the 90s by the afternoon. Finally, Four, does 
it matter meaning higher temperatures with lower dew points or lower 
temperatures with higher dew points will result in similar heat 
index values. Expecting heat index values of 95 to low 100s on 
Saturday and roughly 100 to 105 on Sunday. Heat will be the key 
messaging this forecast period.

A buckle in the western upper high is still on track sometime Monday 
or Monday night which will drop a boundary into the state. The exact 
timing will play a role on if the heat remains Monday. At this time, 
some relief into northern Iowa is expected but the heat may linger 
central and south. A more active period in the weather looks 
possible by mid next week as a stronger upper level system passes 
through the region.

&&

.AVIATION /18Z TAFS THROUGH 18Z FRIDAY/...
Issued at 1237 PM CDT Thu Jul 11 2024

Mainly VFR conditions are forecast through the TAF period, with
two possible exceptions. First, cumulus clouds forming at the
current time may produce intermittent MVFR ceilings in the next
couple hours, mainly at OTM, before base heights climb above
FL030. Second, light fog/stratus is possible around sunrise
early Friday morning, again with OTM most likely to see impacts,
but even there the probability is too low to include in the TAFs
at this range.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...None.

&&

$$

DISCUSSION...Donavon
AVIATION...Lee
",AFDDMX,2024-07-11 12:37:00-05,KDMX,FXUS63,
"402 
FXUS63 KDMX 111919
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
219 PM CDT Thu Jul 11 2024

.KEY MESSAGES...

- Dry and relatively pleasant weather through Friday.

- Growing warmer this weekend, especially by Sunday when heat
  index values will top 100 degrees in some areas. This may
  occur again on Monday, especially in central and southern
  Iowa.

- Low thunderstorm chances return to northeastern Iowa early
  Sunday morning and early Monday morning, but are more likely 
  in Minnesota and Wisconsin.

&&

.DISCUSSION...
Issued at 219 PM CDT Thu Jul 11 2024

As expected, cumulus field has developed today but has remained
fairly shallow with much less instability than yesterday. The
old upper low continues to move away northeastward into the
Great Lakes, yielding to an overall pleasant day across Iowa
with temperatures currently in the upper 70s to lower 80s and
light winds. Meanwhile, a large heat dome continues to build
over the southwestern and western U.S., and will become the
dominant weather influencer for our region through the weekend
and into early next week.

A surface high pressure ridge currently draped across much of
Wisconsin, Minnesota, Iowa, and northern Illinois will slowly
retreat eastward tonight and Saturday. This will allow low-level
winds to come around to southeast across Iowa by Friday morning,
then south on Saturday. Meanwhile, the nocturnal low-level jet
will return Friday night and we will thereafter see a steady
warm air/moisture advection regime over the weekend, concurrent
with the expanding influence of the aforementioned
western/southwestern heat dome. Initially, on Friday night this
set-up will result in some elevated instability however we will
still be well within the low-level subsidence regime of the
departing high which will help to squelch any convective
initiation. Then on Saturday and Sunday warmer temperatures
aloft should keep us capped off and dry for the most part,
however, this is a classic Ring of Fire scenario in which
shortwave impulses traveling over the top of the western high
trigger diurnally driven thunderstorms which then round the top
and turn southeastward around the periphery of the dome. Most 
model solutions are predicting two or more rounds of such 
thunderstorms over the weekend, however, initiation should be 
well to our north over the Dakotas/Minnesota and at this time it
is uncertain whether the convection will be able to make it as 
far south/southeast as our forecast area. If there is any such 
threat then it would be likeliest in northeastern Iowa during 
the early morning hours of Sunday and Monday.

Aside from some possible thunderstorm hazards in our northeast,
the bigger and more widespread sensible weather impacts from
this regime will be very hot and humid conditions spreading into
the region. Saturday will become warm, but the most oppressive
heat is set for Sunday, and Monday at least in some areas.
Ensemble temperature forecasts for Sunday have ticked up a bit
today, but there are still questions as to the mitigating
factors of evapotranspiration and limited mixing depth due to
capping. As previously discussed however, these factors are
somewhat offsetting in terms of the resulting Heat Index values,
which are likely to near 100 in the south and west on Saturday,
then approach 105 at times Sunday and may warrant a Heat
Advisory issuance in the next day or two. By Monday, however, a
large low pressure gyre will have formed over Hudson Bay, with 
several troughs rounding its base and helping to push the 
southwestern U.S. dome a bit farther south. This will allow a
frontal boundary to sag southward through Iowa sometime Monday
afternoon or night. Oppressive heat will thus continue on
Monday for areas that remain south of that boundary for most of
the afternoon, but there may be some relief in the north
depending on frontal timing. The initial frontal passage may be
relatively dry due to a stout cap in place during the day
Monday, however, the boundary will likely slow or stall
somewhere near the Iowa/Missouri border and on Monday night
active with somewhat more widespread convection as the low-level
jet feeds up into it. From Tuesday through Wednesday a large
surface high pressure area will then build southward from
Minnesota and the Dakotas into Iowa, gradually pushing the old
frontal boundary and any remaining associated rain/storms
southward into Missouri. This should bring relief in the form of
seasonally mild and dry weather to our area by the middle of
next week.

&&

.AVIATION /18Z TAFS THROUGH 18Z FRIDAY/...
Issued at 1237 PM CDT Thu Jul 11 2024

Mainly VFR conditions are forecast through the TAF period, with
two possible exceptions. First, cumulus clouds forming at the
current time may produce intermittent MVFR ceilings in the next
couple hours, mainly at OTM, before base heights climb above
FL030. Second, light fog/stratus is possible around sunrise
early Friday morning, again with OTM most likely to see impacts,
but even there the probability is too low to include in the TAFs
at this range.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Lee
AVIATION...Lee
",AFDDMX,2024-07-11 14:19:00-05,KDMX,FXUS63,
"520 
FXUS63 KDMX 112326
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
626 PM CDT Thu Jul 11 2024

 ...Updated for the 00z Aviation Discussion...

.KEY MESSAGES...

- Dry and relatively pleasant weather through Friday.

- Growing warmer this weekend, especially by Sunday when heat
  index values will top 100 degrees in some areas. This may
  occur again on Monday, especially in central and southern
  Iowa.

- Low thunderstorm chances return to northeastern Iowa early
  Sunday morning and early Monday morning, but are more likely 
  in Minnesota and Wisconsin.

&&

.DISCUSSION...
Issued at 219 PM CDT Thu Jul 11 2024

As expected, cumulus field has developed today but has remained
fairly shallow with much less instability than yesterday. The
old upper low continues to move away northeastward into the
Great Lakes, yielding to an overall pleasant day across Iowa
with temperatures currently in the upper 70s to lower 80s and
light winds. Meanwhile, a large heat dome continues to build
over the southwestern and western U.S., and will become the
dominant weather influencer for our region through the weekend
and into early next week.

A surface high pressure ridge currently draped across much of
Wisconsin, Minnesota, Iowa, and northern Illinois will slowly
retreat eastward tonight and Saturday. This will allow low-level
winds to come around to southeast across Iowa by Friday morning,
then south on Saturday. Meanwhile, the nocturnal low-level jet
will return Friday night and we will thereafter see a steady
warm air/moisture advection regime over the weekend, concurrent
with the expanding influence of the aforementioned
western/southwestern heat dome. Initially, on Friday night this
set-up will result in some elevated instability however we will
still be well within the low-level subsidence regime of the
departing high which will help to squelch any convective
initiation. Then on Saturday and Sunday warmer temperatures
aloft should keep us capped off and dry for the most part,
however, this is a classic Ring of Fire scenario in which
shortwave impulses traveling over the top of the western high
trigger diurnally driven thunderstorms which then round the top
and turn southeastward around the periphery of the dome. Most 
model solutions are predicting two or more rounds of such 
thunderstorms over the weekend, however, initiation should be 
well to our north over the Dakotas/Minnesota and at this time it
is uncertain whether the convection will be able to make it as 
far south/southeast as our forecast area. If there is any such 
threat then it would be likeliest in northeastern Iowa during 
the early morning hours of Sunday and Monday.

Aside from some possible thunderstorm hazards in our northeast,
the bigger and more widespread sensible weather impacts from
this regime will be very hot and humid conditions spreading into
the region. Saturday will become warm, but the most oppressive
heat is set for Sunday, and Monday at least in some areas.
Ensemble temperature forecasts for Sunday have ticked up a bit
today, but there are still questions as to the mitigating
factors of evapotranspiration and limited mixing depth due to
capping. As previously discussed however, these factors are
somewhat offsetting in terms of the resulting Heat Index values,
which are likely to near 100 in the south and west on Saturday,
then approach 105 at times Sunday and may warrant a Heat
Advisory issuance in the next day or two. By Monday, however, a
large low pressure gyre will have formed over Hudson Bay, with 
several troughs rounding its base and helping to push the 
southwestern U.S. dome a bit farther south. This will allow a
frontal boundary to sag southward through Iowa sometime Monday
afternoon or night. Oppressive heat will thus continue on
Monday for areas that remain south of that boundary for most of
the afternoon, but there may be some relief in the north
depending on frontal timing. The initial frontal passage may be
relatively dry due to a stout cap in place during the day
Monday, however, the boundary will likely slow or stall
somewhere near the Iowa/Missouri border and on Monday night
active with somewhat more widespread convection as the low-level
jet feeds up into it. From Tuesday through Wednesday a large
surface high pressure area will then build southward from
Minnesota and the Dakotas into Iowa, gradually pushing the old
frontal boundary and any remaining associated rain/storms
southward into Missouri. This should bring relief in the form of
seasonally mild and dry weather to our area by the middle of
next week.

&&

.AVIATION /00Z TAFS THROUGH 00Z SATURDAY/...
Issued at 626 PM CDT Thu Jul 11 2024

VFR conditions are expected to prevail through the period. There
is a chance for patchy fog development early Friday morning, 
however confidence is low so have kept from TAFs for now. While
wind has shifted at northern sites, winds at southern sites 
KDSM/KOTM have yet to shift to out of the southeast, this will 
occur by 14-16z Friday morning.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Lee
AVIATION...Hagenhoff
",AFDDMX,2024-07-11 18:26:00-05,KDMX,FXUS63,
"274 
FXUS63 KDMX 120242
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
942 PM CDT Thu Jul 11 2024

 ...Updated for the 00z Aviation Discussion...

.KEY MESSAGES...

- Dry and relatively pleasant weather through Friday.

- Growing warmer this weekend, especially by Sunday when heat
  index values will top 100 degrees in some areas. This may
  occur again on Monday, especially in central and southern
  Iowa.

- Low thunderstorm chances return to northeastern Iowa early
  Sunday morning and early Monday morning, but are more likely 
  in Minnesota and Wisconsin.

&&

.DISCUSSION...
Issued at 219 PM CDT Thu Jul 11 2024

As expected, cumulus field has developed today but has remained
fairly shallow with much less instability than yesterday. The
old upper low continues to move away northeastward into the
Great Lakes, yielding to an overall pleasant day across Iowa
with temperatures currently in the upper 70s to lower 80s and
light winds. Meanwhile, a large heat dome continues to build
over the southwestern and western U.S., and will become the
dominant weather influencer for our region through the weekend
and into early next week.

A surface high pressure ridge currently draped across much of
Wisconsin, Minnesota, Iowa, and northern Illinois will slowly
retreat eastward tonight and Saturday. This will allow low-level
winds to come around to southeast across Iowa by Friday morning,
then south on Saturday. Meanwhile, the nocturnal low-level jet
will return Friday night and we will thereafter see a steady
warm air/moisture advection regime over the weekend, concurrent
with the expanding influence of the aforementioned
western/southwestern heat dome. Initially, on Friday night this
set-up will result in some elevated instability however we will
still be well within the low-level subsidence regime of the
departing high which will help to squelch any convective
initiation. Then on Saturday and Sunday warmer temperatures
aloft should keep us capped off and dry for the most part,
however, this is a classic Ring of Fire scenario in which
shortwave impulses traveling over the top of the western high
trigger diurnally driven thunderstorms which then round the top
and turn southeastward around the periphery of the dome. Most 
model solutions are predicting two or more rounds of such 
thunderstorms over the weekend, however, initiation should be 
well to our north over the Dakotas/Minnesota and at this time it
is uncertain whether the convection will be able to make it as 
far south/southeast as our forecast area. If there is any such 
threat then it would be likeliest in northeastern Iowa during 
the early morning hours of Sunday and Monday.

Aside from some possible thunderstorm hazards in our northeast,
the bigger and more widespread sensible weather impacts from
this regime will be very hot and humid conditions spreading into
the region. Saturday will become warm, but the most oppressive
heat is set for Sunday, and Monday at least in some areas.
Ensemble temperature forecasts for Sunday have ticked up a bit
today, but there are still questions as to the mitigating
factors of evapotranspiration and limited mixing depth due to
capping. As previously discussed however, these factors are
somewhat offsetting in terms of the resulting Heat Index values,
which are likely to near 100 in the south and west on Saturday,
then approach 105 at times Sunday and may warrant a Heat
Advisory issuance in the next day or two. By Monday, however, a
large low pressure gyre will have formed over Hudson Bay, with 
several troughs rounding its base and helping to push the 
southwestern U.S. dome a bit farther south. This will allow a
frontal boundary to sag southward through Iowa sometime Monday
afternoon or night. Oppressive heat will thus continue on
Monday for areas that remain south of that boundary for most of
the afternoon, but there may be some relief in the north
depending on frontal timing. The initial frontal passage may be
relatively dry due to a stout cap in place during the day
Monday, however, the boundary will likely slow or stall
somewhere near the Iowa/Missouri border and on Monday night
active with somewhat more widespread convection as the low-level
jet feeds up into it. From Tuesday through Wednesday a large
surface high pressure area will then build southward from
Minnesota and the Dakotas into Iowa, gradually pushing the old
frontal boundary and any remaining associated rain/storms
southward into Missouri. This should bring relief in the form of
seasonally mild and dry weather to our area by the middle of
next week.

&&

.AVIATION /00Z TAFS THROUGH 00Z SATURDAY/...
Issued at 942 PM CDT Thu Jul 11 2024

VFR conditions are expected to prevail through the TAF period.
Patchy light fog is possible, mainly in southern Iowa, Friday
morning however recent data suggests this should not bring 
conditions out of VFR so have kept from TAFs at this time.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Lee
AVIATION...Hagenhoff
",AFDDMX,2024-07-11 21:42:00-05,KDMX,FXUS63,
"224 
FXUS63 KDMX 120921
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
421 AM CDT Fri Jul 12 2024

.KEY MESSAGES...

- Increasing temperatures through the weekend with heat index
  values exceeding 100F starting Saturday and values pushing
  105F on Sunday. 

- Scattered shower and thunderstorm chances possible tonight.
  Few stronger storms are possible, but overall severe threat 
  is low.

- Additional shower and thunderstorm chances into the beginning
  of the week. 

&&

.DISCUSSION...
Issued at 415 AM CDT Fri Jul 12 2024

Conditions across the state tonight have remained fairly quiet as 
surface high pressure  and overall subsidence remains in place 
overhead, keeping skies clear and winds light. Radiational cooling 
has allowed temperatures to fall into the low to mid 60s early this 
morning, which has produced some transient fog at some locations, 
albeit far from widespread. Will likely see brief periods of fog 
here and there through the morning, but not expecting anything 
widespread.  

High pressure remains in place through the day, making for pleasant 
conditions again today. However, the pattern begins to slowly change 
as the upper level ridging to our southwest builds further east 
across the U.S., bringing warmer temperatures, as well as a few 
chances for showers and thunderstorms. First, in regards to the 
heat, we will see 850 hPa temperatures increasing today through the 
weekend and peaking in the mid to upper 20s celsius on Sunday and 
Monday. This will translate to warm surface temperatures, with highs 
in the upper 80s and 90s Saturday through Monday, with the warmest 
day being Sunday with highs in the low to mid 90s area-wide. This, 
in conjunction with surface dewpoints in the 70s will make for 
sticky conditions through the weekend. Heat index values starting 
Saturday will be near or exceeding 100F through Monday, with values 
over 105 likely on Sunday and potentially again Monday. Given these 
heat index values, would expect that a heat advisory will be needed 
for at least Sunday, but have held off on any headline issuances for 
this forecast cycle. Upper level troughing will start to push the 
heat dome back south, dropping a cool front through the state on 
Monday. The progression of this cool front, and how it’s location 
changes based on any ongoing convection, will have effect on highs 
Monday, especially in the north. Once the boundary passes through, 
temperatures return to more normal to even slightly below normal 
values through the middle of next week.

Weak waves propagating along the edge of the upper level ridging 
will also bring multiple chances for showers and thunderstorms to 
the region through the weekend. Since the forcing throughout this 
period is weak, CAMs are struggling with resolving precipitation, 
making exact details of location and timing tricky. Making matters 
worse is the warm temperatures aloft that try to keep much of the 
state capped off. Therefore, confidence is low on the specifics of 
showers and storms this weekend. The first favorable period for 
showers and storms looks to be tonight into early Saturday morning 
as theta-e advection arrives in the state, and the LLJ noses up into 
southern Iowa. The severe environment will be fairly typical for 
this time of year, with ~1500 to 2000 J/kg of instability but 
relatively weak deep layer flow keeping the 0-6 km bulk shear values 
marginal around 20 to 30 kts. Therefore, can’t rule out a stronger 
storm producing some small hail or brief gusty winds, especially 
with the dry layer near the surface, but the severe weather threat 
looks low as storms will likely remain elevated. SPC does have a 
marginal risk for severe weather over the northern portions of the 
area, but this seems to be contingent on a more organized MCS 
forming in the northern states and persisting into Iowa through 
daybreak. The chances for this scenario look to be trending down, 
hence the removal of the slight risk with the Day 2 outlook, but 
will continue to monitor for this possibility through the coming 
days. 

Additional shower and thunderstorm chances are possible again Sunday 
into Monday, but primarily favor areas to our north and to our east. 
That being said, with a similar airmass overhead, concerns for some 
form of MCS leaking into our area, as well as the possibility for 
some bubbling convection along the LLJ overnight will continue 
Sunday night into Monday morning. Finally, more chances develop as 
the previously mentioned boundary sags south into the state on 
Monday and provides the necessary forcing for storms to develop 
along it Monday afternoon and evening. Both stronger storms and 
potentially heavy rainfall will be possible as this front passes 
through, but will continue to evaluate the risks in coming days. 
&&

.AVIATION /06Z TAFS THROUGH 06Z SATURDAY/...
Issued at 942 PM CDT Thu Jul 11 2024

VFR conditions are expected to prevail through the TAF period.
Patchy light fog is possible, mainly in southern Iowa, Friday
morning however recent data suggests this should not bring 
conditions out of VFR so have kept from TAFs at this time.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Dodson
AVIATION...Hagenhoff
",AFDDMX,2024-07-12 04:21:00-05,KDMX,FXUS63,
"080 
FXUS63 KDMX 121120
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
620 AM CDT Fri Jul 12 2024

 ...Updated for the 12z Aviation Discussion...

.KEY MESSAGES...

- Increasing temperatures through the weekend with heat index
  values exceeding 100F starting Saturday and values pushing
  105F on Sunday. 

- Scattered shower and thunderstorm chances possible tonight.
  Few stronger storms are possible, but overall severe threat 
  is low.

- Additional shower and thunderstorm chances into the beginning
  of the week.

&&

.DISCUSSION...
Issued at 415 AM CDT Fri Jul 12 2024

Conditions across the state tonight have remained fairly quiet as 
surface high pressure  and overall subsidence remains in place 
overhead, keeping skies clear and winds light. Radiational cooling 
has allowed temperatures to fall into the low to mid 60s early this 
morning, which has produced some transient fog at some locations, 
albeit far from widespread. Will likely see brief periods of fog 
here and there through the morning, but not expecting anything 
widespread.  

High pressure remains in place through the day, making for pleasant 
conditions again today. However, the pattern begins to slowly change 
as the upper level ridging to our southwest builds further east 
across the U.S., bringing warmer temperatures, as well as a few 
chances for showers and thunderstorms. First, in regards to the 
heat, we will see 850 hPa temperatures increasing today through the 
weekend and peaking in the mid to upper 20s celsius on Sunday and 
Monday. This will translate to warm surface temperatures, with highs 
in the upper 80s and 90s Saturday through Monday, with the warmest 
day being Sunday with highs in the low to mid 90s area-wide. This, 
in conjunction with surface dewpoints in the 70s will make for 
sticky conditions through the weekend. Heat index values starting 
Saturday will be near or exceeding 100F through Monday, with values 
over 105 likely on Sunday and potentially again Monday. Given these 
heat index values, would expect that a heat advisory will be needed 
for at least Sunday, but have held off on any headline issuances for 
this forecast cycle. Upper level troughing will start to push the 
heat dome back south, dropping a cool front through the state on 
Monday. The progression of this cool front, and how it’s location 
changes based on any ongoing convection, will have effect on highs 
Monday, especially in the north. Once the boundary passes through, 
temperatures return to more normal to even slightly below normal 
values through the middle of next week.

Weak waves propagating along the edge of the upper level ridging 
will also bring multiple chances for showers and thunderstorms to 
the region through the weekend. Since the forcing throughout this 
period is weak, CAMs are struggling with resolving precipitation, 
making exact details of location and timing tricky. Making matters 
worse is the warm temperatures aloft that try to keep much of the 
state capped off. Therefore, confidence is low on the specifics of 
showers and storms this weekend. The first favorable period for 
showers and storms looks to be tonight into early Saturday morning 
as theta-e advection arrives in the state, and the LLJ noses up into 
southern Iowa. The severe environment will be fairly typical for 
this time of year, with ~1500 to 2000 J/kg of instability but 
relatively weak deep layer flow keeping the 0-6 km bulk shear values 
marginal around 20 to 30 kts. Therefore, can’t rule out a stronger 
storm producing some small hail or brief gusty winds, especially 
with the dry layer near the surface, but the severe weather threat 
looks low as storms will likely remain elevated. SPC does have a 
marginal risk for severe weather over the northern portions of the 
area, but this seems to be contingent on a more organized MCS 
forming in the northern states and persisting into Iowa through 
daybreak. The chances for this scenario look to be trending down, 
hence the removal of the slight risk with the Day 2 outlook, but 
will continue to monitor for this possibility through the coming 
days. 

Additional shower and thunderstorm chances are possible again Sunday 
into Monday, but primarily favor areas to our north and to our east. 
That being said, with a similar airmass overhead, concerns for some 
form of MCS leaking into our area, as well as the possibility for 
some bubbling convection along the LLJ overnight will continue 
Sunday night into Monday morning. Finally, more chances develop as 
the previously mentioned boundary sags south into the state on 
Monday and provides the necessary forcing for storms to develop 
along it Monday afternoon and evening. Both stronger storms and 
potentially heavy rainfall will be possible as this front passes 
through, but will continue to evaluate the risks in coming days.

&&

.AVIATION /12Z TAFS THROUGH 12Z SATURDAY/...
Issued at 616 AM CDT Fri Jul 12 2024

Patchy fog has produced MVFR visibilities across the area early
this morning, primarily impacting KOTM and KMCW. Now that the
sun is up and cloud cover is minimal, expecting conditions to 
improve quickly within the next few hours. Otherwise, VFR
conditions are expected through the day.

There is a small chance for an isolated shower or thunderstorm 
tonight into tomorrow morning, but confidence is low in these
impacting any TAF sites.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...Dodson
AVIATION...Dodson
",AFDDMX,2024-07-12 06:20:00-05,KDMX,FXUS63,
"235 
FXUS63 KDMX 121726
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1226 PM CDT Fri Jul 12 2024

 ...Updated for the 18z Aviation Discussion...

.KEY MESSAGES...

- Increasing temperatures through the weekend with heat index
  values exceeding 100F starting Saturday and values pushing
  105F on Sunday. 

- Scattered shower and thunderstorm chances possible tonight.
  Few stronger storms are possible, but overall severe threat 
  is low.

- Additional shower and thunderstorm chances into the beginning
  of the week.

&&

.DISCUSSION...
Issued at 415 AM CDT Fri Jul 12 2024

Conditions across the state tonight have remained fairly quiet as 
surface high pressure  and overall subsidence remains in place 
overhead, keeping skies clear and winds light. Radiational cooling 
has allowed temperatures to fall into the low to mid 60s early this 
morning, which has produced some transient fog at some locations, 
albeit far from widespread. Will likely see brief periods of fog 
here and there through the morning, but not expecting anything 
widespread.  

High pressure remains in place through the day, making for pleasant 
conditions again today. However, the pattern begins to slowly change 
as the upper level ridging to our southwest builds further east 
across the U.S., bringing warmer temperatures, as well as a few 
chances for showers and thunderstorms. First, in regards to the 
heat, we will see 850 hPa temperatures increasing today through the 
weekend and peaking in the mid to upper 20s celsius on Sunday and 
Monday. This will translate to warm surface temperatures, with highs 
in the upper 80s and 90s Saturday through Monday, with the warmest 
day being Sunday with highs in the low to mid 90s area-wide. This, 
in conjunction with surface dewpoints in the 70s will make for 
sticky conditions through the weekend. Heat index values starting 
Saturday will be near or exceeding 100F through Monday, with values 
over 105 likely on Sunday and potentially again Monday. Given these 
heat index values, would expect that a heat advisory will be needed 
for at least Sunday, but have held off on any headline issuances for 
this forecast cycle. Upper level troughing will start to push the 
heat dome back south, dropping a cool front through the state on 
Monday. The progression of this cool front, and how it’s location 
changes based on any ongoing convection, will have effect on highs 
Monday, especially in the north. Once the boundary passes through, 
temperatures return to more normal to even slightly below normal 
values through the middle of next week.

Weak waves propagating along the edge of the upper level ridging 
will also bring multiple chances for showers and thunderstorms to 
the region through the weekend. Since the forcing throughout this 
period is weak, CAMs are struggling with resolving precipitation, 
making exact details of location and timing tricky. Making matters 
worse is the warm temperatures aloft that try to keep much of the 
state capped off. Therefore, confidence is low on the specifics of 
showers and storms this weekend. The first favorable period for 
showers and storms looks to be tonight into early Saturday morning 
as theta-e advection arrives in the state, and the LLJ noses up into 
southern Iowa. The severe environment will be fairly typical for 
this time of year, with ~1500 to 2000 J/kg of instability but 
relatively weak deep layer flow keeping the 0-6 km bulk shear values 
marginal around 20 to 30 kts. Therefore, can’t rule out a stronger 
storm producing some small hail or brief gusty winds, especially 
with the dry layer near the surface, but the severe weather threat 
looks low as storms will likely remain elevated. SPC does have a 
marginal risk for severe weather over the northern portions of the 
area, but this seems to be contingent on a more organized MCS 
forming in the northern states and persisting into Iowa through 
daybreak. The chances for this scenario look to be trending down, 
hence the removal of the slight risk with the Day 2 outlook, but 
will continue to monitor for this possibility through the coming 
days. 

Additional shower and thunderstorm chances are possible again Sunday 
into Monday, but primarily favor areas to our north and to our east. 
That being said, with a similar airmass overhead, concerns for some 
form of MCS leaking into our area, as well as the possibility for 
some bubbling convection along the LLJ overnight will continue 
Sunday night into Monday morning. Finally, more chances develop as 
the previously mentioned boundary sags south into the state on 
Monday and provides the necessary forcing for storms to develop 
along it Monday afternoon and evening. Both stronger storms and 
potentially heavy rainfall will be possible as this front passes 
through, but will continue to evaluate the risks in coming days.

&&

.AVIATION /18Z TAFS THROUGH 18Z SATURDAY/...
Issued at 1212 PM CDT Fri Jul 12 2024

Cumulus continues to develop into the heating of the afternoon
south and west, but most of the ceilings should be VFR. Some
cumulus may linger into the night as well, but some mid 
cloudiness may develop too along with a low potential for 
convection. The precipitation chances are too low to include at
the moment however, so generally VFR conditions are anticipated
for the remainder of the period.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...None.

&&

$$

DISCUSSION...Dodson
AVIATION...Small
",AFDDMX,2024-07-12 12:26:00-05,KDMX,FXUS63,
"610 
FXUS63 KDMX 122008
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
308 PM CDT Fri Jul 12 2024

.KEY MESSAGES...

- Heat continues to build through the weekend, with peak heat
  indices 105F+ south and west Sun and Mon

- Low confidence in convective trends through the weekend, but
  potential increases somewhat with frontal passage Mon night
  into Tue

- Drier with more seasonal temps and lower humidity for the
  latter portions of next week

&&

.DISCUSSION...
Issued at 302 PM CDT Fri Jul 12 2024

The weather pattern over the next several days will be 
characterized by a gradual expansion of the broad Rockies upper 
ridge a bit farther into the MO Valley which will increase our 
heat and humidity, while the northern Plains will see faster 
mid/upper level flow and the passage of a few short waves 
keeping convection more active there. Our weather will mainly be
dominated by the heat dome through the weekend, but in 
sufficient proximity to the active westerlies that confidence in
convective trends is reduced and precip cannot be ruled out.

At the moment this afternoon, cumulus continues to develop 
south and west in the peak heating of the day along and south of
the 1.5km moisture gradient. Farther to the west elevated 
convective debris lingers across NE associated with the H85/H7 
baroclinic zone. Theta-e advection associated with the 
baroclinic zone is expected to advanced north and east through 
the night ushering in our elevated heat and humidity for the 
weekend, and should mainly be dry due to sufficient CINH surface
and aloft. However some models are hinting that the 
thermodynamic forcing may align with the better moisture 
currently over southern IA so have mentioned some slight chances
there, but as mentioned in the above paragraph confidence in 
convective trends is low.

For tomorrow, any nocturnally driven potential should wane with
the primary concern turning to elevated heat and humidity. 
Highs 90-95F are anticipated across the southwest half, and with
advection and evapotranspiration boosted dewpoints to above 70F
peak afternoon heat indices are expected to reach 105F+ 
generally over the southwest half of the area. Thus have issued 
a Heat Advisory for those locations. Similar values are expected
Sunday and potentially Monday, but with the aforementioned 
convective uncertainty consensus among surrounding offices leads
to taking heat headlines one day at time. While not a strong 
trend, convection allowing and parameterized models both suggest
some potential for some nocturnal convection Sat night so have 
added a some slight chances through central portions of the 
state. Sunday should see very similar heat and humidity 
parameters, with heat indices 105F+ southwest half, so another 
Heat Advisory could very well be needed depending on overnight 
convection and its strength if it occurs.

By Monday the deepening long wave trough which will eventually 
end our heat episode should be traversing the northern Plains 
with lingering convection from Sunday night dropping through the
Upper MS Valley and possibly entering northeastern IA when 
confidence in convective trends begins increasing somewhat with 
sharper focusing mechanisms. A cold front is expected to begin 
entering northern sections during the afternoon, but MLCINH is 
expected to keep much of the convection at bay until low level 
jet contributions increase moisture transport and 0-2km 
convergence. Effective shear is expected to be moderate at best,
but there will be some severe potential in this window due to 
the degree of instability. The most robust convective potential 
should end early Tue as the surface front exits the state, 
however the NBM suggests weak waves traversing the base of the 
long wave trough will still keep chances for showers and a few 
storms in the forecast through early Wed.

Once the lingering effects of the departing frontal boundary end
early Wednesday, the remainder of the week should be dry with
seasonal temps and dewpoints, or even a touch below normal. The
model solutions are in good agreement with weak northwest flow 
aloft after the Ontario long wave trough passes, but show varied
placement of the associated surface high (northern Plains vs 
Great Lakes). However most solutions suggest generally eastern 
low level trajectories which would support a more pleasant temp 
and dewpoint regime.

&&

.AVIATION /18Z TAFS THROUGH 18Z SATURDAY/...
Issued at 1212 PM CDT Fri Jul 12 2024

Cumulus continues to develop into the heating of the afternoon
south and west, but most of the ceilings should be VFR. Some
cumulus may linger into the night as well, but some mid 
cloudiness may develop too along with a low potential for 
convection. The precipitation chances are too low to include at
the moment however, so generally VFR conditions are anticipated
for the remainder of the period.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM to 8 PM CDT Saturday for IAZ023-
033>035-044>048-057>061-070>075-081>086-092>097.

&&

$$

DISCUSSION...Small
AVIATION...Small
",AFDDMX,2024-07-12 15:08:00-05,KDMX,FXUS63,
"953 
FXUS63 KDMX 122325
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
625 PM CDT Fri Jul 12 2024

 ...Updated for the 00z Aviation Discussion...

.KEY MESSAGES...

- Heat continues to build through the weekend, with peak heat
  indices 105F+ south and west Sun and Mon

- Low confidence in convective trends through the weekend, but
  potential increases somewhat with frontal passage Mon night
  into Tue

- Drier with more seasonal temps and lower humidity for the
  latter portions of next week

&&

.DISCUSSION...
Issued at 302 PM CDT Fri Jul 12 2024

The weather pattern over the next several days will be 
characterized by a gradual expansion of the broad Rockies upper 
ridge a bit farther into the MO Valley which will increase our 
heat and humidity, while the northern Plains will see faster 
mid/upper level flow and the passage of a few short waves 
keeping convection more active there. Our weather will mainly be
dominated by the heat dome through the weekend, but in 
sufficient proximity to the active westerlies that confidence in
convective trends is reduced and precip cannot be ruled out.

At the moment this afternoon, cumulus continues to develop 
south and west in the peak heating of the day along and south of
the 1.5km moisture gradient. Farther to the west elevated 
convective debris lingers across NE associated with the H85/H7 
baroclinic zone. Theta-e advection associated with the 
baroclinic zone is expected to advanced north and east through 
the night ushering in our elevated heat and humidity for the 
weekend, and should mainly be dry due to sufficient CINH surface
and aloft. However some models are hinting that the 
thermodynamic forcing may align with the better moisture 
currently over southern IA so have mentioned some slight chances
there, but as mentioned in the above paragraph confidence in 
convective trends is low.

For tomorrow, any nocturnally driven potential should wane with
the primary concern turning to elevated heat and humidity. 
Highs 90-95F are anticipated across the southwest half, and with
advection and evapotranspiration boosted dewpoints to above 70F
peak afternoon heat indices are expected to reach 105F+ 
generally over the southwest half of the area. Thus have issued 
a Heat Advisory for those locations. Similar values are expected
Sunday and potentially Monday, but with the aforementioned 
convective uncertainty consensus among surrounding offices leads
to taking heat headlines one day at time. While not a strong 
trend, convection allowing and parameterized models both suggest
some potential for some nocturnal convection Sat night so have 
added a some slight chances through central portions of the 
state. Sunday should see very similar heat and humidity 
parameters, with heat indices 105F+ southwest half, so another 
Heat Advisory could very well be needed depending on overnight 
convection and its strength if it occurs.

By Monday the deepening long wave trough which will eventually 
end our heat episode should be traversing the northern Plains 
with lingering convection from Sunday night dropping through the
Upper MS Valley and possibly entering northeastern IA when 
confidence in convective trends begins increasing somewhat with 
sharper focusing mechanisms. A cold front is expected to begin 
entering northern sections during the afternoon, but MLCINH is 
expected to keep much of the convection at bay until low level 
jet contributions increase moisture transport and 0-2km 
convergence. Effective shear is expected to be moderate at best,
but there will be some severe potential in this window due to 
the degree of instability. The most robust convective potential 
should end early Tue as the surface front exits the state, 
however the NBM suggests weak waves traversing the base of the 
long wave trough will still keep chances for showers and a few 
storms in the forecast through early Wed.

Once the lingering effects of the departing frontal boundary end
early Wednesday, the remainder of the week should be dry with
seasonal temps and dewpoints, or even a touch below normal. The
model solutions are in good agreement with weak northwest flow 
aloft after the Ontario long wave trough passes, but show varied
placement of the associated surface high (northern Plains vs 
Great Lakes). However most solutions suggest generally eastern 
low level trajectories which would support a more pleasant temp 
and dewpoint regime.

&&

.AVIATION /00Z TAFS THROUGH 00Z SUNDAY/...
Issued at 625 PM CDT Fri Jul 12 2024

Scattered cumulus clouds remain over the area early this evening, 
hovering just above VFR thresholds. Much of this cloud cover will 
break up overnight, and any lingering clouds remain VFR. Isolated 
TSRA are possible overnight, mainly over southern Iowa. Confidence 
in convective trends is much too low to warrant mention in at any 
particular terminal at this time. VFR conditions continue into 
Saturday with few to sct cumulus near 10k ft and southerly winds 
increasing to around 10 kts with gusts near 15-20 kts at times.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM to 8 PM CDT Saturday for IAZ023-
033>035-044>048-057>061-070>075-081>086-092>097.

&&

$$

DISCUSSION...Small
AVIATION...Martin
",AFDDMX,2024-07-12 18:25:00-05,KDMX,FXUS63,
"962 
FXUS63 KDMX 130432
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1132 PM CDT Fri Jul 12 2024

 ...Updated for the 06z Aviation Discussion...

.KEY MESSAGES...

- Heat continues to build through the weekend, with peak heat
  indices 105F+ south and west Sun and Mon

- Low confidence in convective trends through the weekend, but
  potential increases somewhat with frontal passage Mon night
  into Tue

- Drier with more seasonal temps and lower humidity for the
  latter portions of next week

&&

.DISCUSSION...
Issued at 302 PM CDT Fri Jul 12 2024

The weather pattern over the next several days will be 
characterized by a gradual expansion of the broad Rockies upper 
ridge a bit farther into the MO Valley which will increase our 
heat and humidity, while the northern Plains will see faster 
mid/upper level flow and the passage of a few short waves 
keeping convection more active there. Our weather will mainly be
dominated by the heat dome through the weekend, but in 
sufficient proximity to the active westerlies that confidence in
convective trends is reduced and precip cannot be ruled out.

At the moment this afternoon, cumulus continues to develop 
south and west in the peak heating of the day along and south of
the 1.5km moisture gradient. Farther to the west elevated 
convective debris lingers across NE associated with the H85/H7 
baroclinic zone. Theta-e advection associated with the 
baroclinic zone is expected to advanced north and east through 
the night ushering in our elevated heat and humidity for the 
weekend, and should mainly be dry due to sufficient CINH surface
and aloft. However some models are hinting that the 
thermodynamic forcing may align with the better moisture 
currently over southern IA so have mentioned some slight chances
there, but as mentioned in the above paragraph confidence in 
convective trends is low.

For tomorrow, any nocturnally driven potential should wane with
the primary concern turning to elevated heat and humidity. 
Highs 90-95F are anticipated across the southwest half, and with
advection and evapotranspiration boosted dewpoints to above 70F
peak afternoon heat indices are expected to reach 105F+ 
generally over the southwest half of the area. Thus have issued 
a Heat Advisory for those locations. Similar values are expected
Sunday and potentially Monday, but with the aforementioned 
convective uncertainty consensus among surrounding offices leads
to taking heat headlines one day at time. While not a strong 
trend, convection allowing and parameterized models both suggest
some potential for some nocturnal convection Sat night so have 
added a some slight chances through central portions of the 
state. Sunday should see very similar heat and humidity 
parameters, with heat indices 105F+ southwest half, so another 
Heat Advisory could very well be needed depending on overnight 
convection and its strength if it occurs.

By Monday the deepening long wave trough which will eventually 
end our heat episode should be traversing the northern Plains 
with lingering convection from Sunday night dropping through the
Upper MS Valley and possibly entering northeastern IA when 
confidence in convective trends begins increasing somewhat with 
sharper focusing mechanisms. A cold front is expected to begin 
entering northern sections during the afternoon, but MLCINH is 
expected to keep much of the convection at bay until low level 
jet contributions increase moisture transport and 0-2km 
convergence. Effective shear is expected to be moderate at best,
but there will be some severe potential in this window due to 
the degree of instability. The most robust convective potential 
should end early Tue as the surface front exits the state, 
however the NBM suggests weak waves traversing the base of the 
long wave trough will still keep chances for showers and a few 
storms in the forecast through early Wed.

Once the lingering effects of the departing frontal boundary end
early Wednesday, the remainder of the week should be dry with
seasonal temps and dewpoints, or even a touch below normal. The
model solutions are in good agreement with weak northwest flow 
aloft after the Ontario long wave trough passes, but show varied
placement of the associated surface high (northern Plains vs 
Great Lakes). However most solutions suggest generally eastern 
low level trajectories which would support a more pleasant temp 
and dewpoint regime.

&&

.AVIATION /06Z TAFS THROUGH 06Z SUNDAY/...
Issued at 1131 PM CDT Fri Jul 12 2024

VFR conditions are forecast to prevail through the TAF period. TSRA 
potential remains quite uncertain, however model guidance suggests 
there may be some iso/sct activity early Saturday morning in 
southern Iowa, then shifting into northern Iowa by late Saturday 
evening. The likelihood of TSRA occurrence at any particular 
terminal is low, and thus still held off on any mention in this 
TAF issuance. 

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM to 8 PM CDT Saturday for IAZ023-
033>035-044>048-057>061-070>075-081>086-092>097.

&&

$$

DISCUSSION...Small
AVIATION...Martin
",AFDDMX,2024-07-12 23:32:00-05,KDMX,FXUS63,
"673 
FXUS63 KDMX 130913
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
413 AM CDT Sat Jul 13 2024

.KEY MESSAGES...

- Hot and humid temperatures with heat index values of 100 to
  105F today through Monday. 

- Possibility for thunderstorms tonight into tomorrow morning,
  with strong winds and heavy rainfall the main concern.

- Additional shower and thunderstorm chances on Monday, with a
  few strong storms and heavy rain again possible in the
  afternoon.
  

&&

.DISCUSSION...
Issued at 410 AM CDT Sat Jul 13 2024

Upper level ridging continues to build in from the southwest US, as 
multiple areas of convection are seen throughout the plains region 
as weak waves propagate along the peripheral of the high pressure. 
Fortunately, much of the activity remains north and west of the 
state where the stronger theta-e advection wing resides and stronger 
moisture convergence is present. That being said, should the 
convective activity to our north and west (particularly the MCS 
currently over western Minnesota as of the time of writing this) 
hold on through the morning hours, could potentially see some 
convection leak into northern Iowa today. Models aren’t necessarily 
capturing this well, so will be monitoring convective trends closely 
through the early morning hours. 

Our first day of hot and humid temperatures begins today, as the 
influence of the heat dome begins to take hold of the state. This is 
indicated by the 850 temperatures of 20+ celsius now in place over 
western Iowa. Warm 850 temperatures will expand east through the 
morning, pushing highs into the 90s over roughly the southwestern 
half of Iowa. These temperatures will combine with some sticky 70+ 
dewpoints to put heat indices near 100F for most and up to 105F for 
some. Therefore, the heat advisory remains in place for much of 
western, central and southern Iowa today, with a slight expansion 
further north during this forecast cycle. 

Looking ahead to tonight, the upper level ridge and associated low-
level moisture plume continues further east, which will open up the 
chances for some storms tonight into Sunday. As mentioned 
previously, weak waves will be kicking off convection through the 
overall northwest flow, but a definitive forcing mechanism isn’t 
really apparent as this occurs. This lack of forcing will negate 
storm development during the day, thanks to the warm layer aloft 
putting a stop to any parcels that are displaced. However, 
uncertainty increases greatly when you consider the convection 
occurring across the north today, especially as the atmosphere 
decouples this evening and the LLJ ramps up overhead. CAMs have been 
all over the place for thunderstorm progression, ranging anywhere 
from an MCS dropping into northern Iowa to nobody in the forecast 
area seeing a single drop of rainfall. Therefore, without any strong 
forcing mechanism to keep an eye and lack of reliable model 
guidance, confidence is low on how convection will play out tonight. 
Storm prediction will rely heavily on identifying mesoscale features 
and monitoring trends through the day today and into tonight. If an 
MCS were to drop into the state tonight/tomorrow morning, strong 
winds and brief heavy rainfall would be the main severe weather 
concerns, which SPC has highlighted with their day 1 slight risk for 
severe weather across far northeast Iowa. 

The hot and humid conditions continue through Sunday, with slightly 
warmer highs in the low to mid 90s and widespread heat index values 
of 100 to 105F. A heat advisory will likely be needed once again on 
Sunday, but have continued the day by day strategy for issuing 
headlines given the uncertainty of convection tonight and how that 
may affect highs Sunday. The heat dome then begins to break apart on 
Monday, as a cool front pushes the warmer temperatures further 
south. That being said, expecting temperatures on the warm side of 
the front to again be nearing advisory criteria with more high 
temperatures in the 90s on Monday. The extent of these temperatures 
will be contingent on the location of the front on Monday, as well 
as any convection and resultant cloud cover that develops along it. 
Guidance continues to show thunderstorms developing along the 
boundary as it pushes south on Monday, but has backed off on the 
extent of storms further west in the state. This is likely due to 
the warm layer still present along the boundary and large amounts of 
CINH preceding it. That being said, bulk shear values around 30 to 
35 kts and plenty of instability will make Monday worth keeping an 
eye on, especially with PWATs of 2”+ pooling along the front. SPC 
currently has a marginal risk area wide, with a slight risk clipping 
our far northeast. 

&&

.AVIATION /06Z TAFS THROUGH 06Z SUNDAY/...
Issued at 1131 PM CDT Fri Jul 12 2024

VFR conditions are forecast to prevail through the TAF period. TSRA 
potential remains quite uncertain, however model guidance suggests 
there may be some iso/sct activity early Saturday morning in 
southern Iowa, then shifting into northern Iowa by late Saturday 
evening. The likelihood of TSRA occurrence at any particular 
terminal is low, and thus still held off on any mention in this 
TAF issuance.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ004-015-023-024-033>035-044>048-057>061-070>075-
081>086-092>097.

&&

$$

DISCUSSION...Dodson
AVIATION...Martin
",AFDDMX,2024-07-13 04:13:00-05,KDMX,FXUS63,
"077 
FXUS63 KDMX 131119
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
619 AM CDT Sat Jul 13 2024

 ...Updated for the 12z Aviation Discussion...

.KEY MESSAGES...

- Hot and humid temperatures with heat index values of 100 to
  105F today through Monday. 

- Possibility for thunderstorms tonight into tomorrow morning,
  with strong winds and heavy rainfall the main concern.

- Additional shower and thunderstorm chances on Monday, with a
  few strong storms and heavy rain again possible in the
  afternoon.

&&

.DISCUSSION...
Issued at 410 AM CDT Sat Jul 13 2024

Upper level ridging continues to build in from the southwest US, as 
multiple areas of convection are seen throughout the plains region 
as weak waves propagate along the peripheral of the high pressure. 
Fortunately, much of the activity remains north and west of the 
state where the stronger theta-e advection wing resides and stronger 
moisture convergence is present. That being said, should the 
convective activity to our north and west (particularly the MCS 
currently over western Minnesota as of the time of writing this) 
hold on through the morning hours, could potentially see some 
convection leak into northern Iowa today. Models aren’t necessarily 
capturing this well, so will be monitoring convective trends closely 
through the early morning hours. 

Our first day of hot and humid temperatures begins today, as the 
influence of the heat dome begins to take hold of the state. This is 
indicated by the 850 temperatures of 20+ celsius now in place over 
western Iowa. Warm 850 temperatures will expand east through the 
morning, pushing highs into the 90s over roughly the southwestern 
half of Iowa. These temperatures will combine with some sticky 70+ 
dewpoints to put heat indices near 100F for most and up to 105F for 
some. Therefore, the heat advisory remains in place for much of 
western, central and southern Iowa today, with a slight expansion 
further north during this forecast cycle. 

Looking ahead to tonight, the upper level ridge and associated low-
level moisture plume continues further east, which will open up the 
chances for some storms tonight into Sunday. As mentioned 
previously, weak waves will be kicking off convection through the 
overall northwest flow, but a definitive forcing mechanism isn’t 
really apparent as this occurs. This lack of forcing will negate 
storm development during the day, thanks to the warm layer aloft 
putting a stop to any parcels that are displaced. However, 
uncertainty increases greatly when you consider the convection 
occurring across the north today, especially as the atmosphere 
decouples this evening and the LLJ ramps up overhead. CAMs have been 
all over the place for thunderstorm progression, ranging anywhere 
from an MCS dropping into northern Iowa to nobody in the forecast 
area seeing a single drop of rainfall. Therefore, without any strong 
forcing mechanism to keep an eye and lack of reliable model 
guidance, confidence is low on how convection will play out tonight. 
Storm prediction will rely heavily on identifying mesoscale features 
and monitoring trends through the day today and into tonight. If an 
MCS were to drop into the state tonight/tomorrow morning, strong 
winds and brief heavy rainfall would be the main severe weather 
concerns, which SPC has highlighted with their day 1 slight risk for 
severe weather across far northeast Iowa. 

The hot and humid conditions continue through Sunday, with slightly 
warmer highs in the low to mid 90s and widespread heat index values 
of 100 to 105F. A heat advisory will likely be needed once again on 
Sunday, but have continued the day by day strategy for issuing 
headlines given the uncertainty of convection tonight and how that 
may affect highs Sunday. The heat dome then begins to break apart on 
Monday, as a cool front pushes the warmer temperatures further 
south. That being said, expecting temperatures on the warm side of 
the front to again be nearing advisory criteria with more high 
temperatures in the 90s on Monday. The extent of these temperatures 
will be contingent on the location of the front on Monday, as well 
as any convection and resultant cloud cover that develops along it. 
Guidance continues to show thunderstorms developing along the 
boundary as it pushes south on Monday, but has backed off on the 
extent of storms further west in the state. This is likely due to 
the warm layer still present along the boundary and large amounts of 
CINH preceding it. That being said, bulk shear values around 30 to 
35 kts and plenty of instability will make Monday worth keeping an 
eye on, especially with PWATs of 2”+ pooling along the front. SPC 
currently has a marginal risk area wide, with a slight risk clipping 
our far northeast.

&&

.AVIATION /12Z TAFS THROUGH 12Z SUNDAY/...
Issued at 615 AM CDT Sat Jul 13 2024

Patchy MVFR fog has developed again this morning at KFOD and 
KMCW, but anticipating this to dissipate within the next hour 
or two. There is a storm system currently tracking southeast 
across Minnesota early this morning, which could clip KMCW 
around 15 to 16z, if it holds on that long. However, this is 
expected to weaken through the next few hours, so have left 
mention out of TAFs for now, and will amend if storms are 
imminent. Otherwise, VFR conditions prevail through the day with
some additional low confidence storms possible near KMCW and 
KALO tonight into tomorrow morning. 

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ004-015-023-024-033>035-044>048-057>061-070>075-
081>086-092>097.

&&

$$

DISCUSSION...Dodson
AVIATION...Dodson
",AFDDMX,2024-07-13 06:19:00-05,KDMX,FXUS63,
"331 
FXUS63 KDMX 131749
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1249 PM CDT Sat Jul 13 2024

 ...Updated for the 18z Aviation Discussion...

.KEY MESSAGES...

- Hot and humid temperatures with heat index values of 100 to
  105F today through Monday. 

- Possibility for thunderstorms tonight into tomorrow morning,
  with strong winds and heavy rainfall the main concern.

- Additional shower and thunderstorm chances on Monday, with a
  few strong storms and heavy rain again possible in the
  afternoon.

&&

.DISCUSSION...
Issued at 410 AM CDT Sat Jul 13 2024

Upper level ridging continues to build in from the southwest US, as 
multiple areas of convection are seen throughout the plains region 
as weak waves propagate along the peripheral of the high pressure. 
Fortunately, much of the activity remains north and west of the 
state where the stronger theta-e advection wing resides and stronger 
moisture convergence is present. That being said, should the 
convective activity to our north and west (particularly the MCS 
currently over western Minnesota as of the time of writing this) 
hold on through the morning hours, could potentially see some 
convection leak into northern Iowa today. Models aren’t necessarily 
capturing this well, so will be monitoring convective trends closely 
through the early morning hours. 

Our first day of hot and humid temperatures begins today, as the 
influence of the heat dome begins to take hold of the state. This is 
indicated by the 850 temperatures of 20+ celsius now in place over 
western Iowa. Warm 850 temperatures will expand east through the 
morning, pushing highs into the 90s over roughly the southwestern 
half of Iowa. These temperatures will combine with some sticky 70+ 
dewpoints to put heat indices near 100F for most and up to 105F for 
some. Therefore, the heat advisory remains in place for much of 
western, central and southern Iowa today, with a slight expansion 
further north during this forecast cycle. 

Looking ahead to tonight, the upper level ridge and associated low-
level moisture plume continues further east, which will open up the 
chances for some storms tonight into Sunday. As mentioned 
previously, weak waves will be kicking off convection through the 
overall northwest flow, but a definitive forcing mechanism isn’t 
really apparent as this occurs. This lack of forcing will negate 
storm development during the day, thanks to the warm layer aloft 
putting a stop to any parcels that are displaced. However, 
uncertainty increases greatly when you consider the convection 
occurring across the north today, especially as the atmosphere 
decouples this evening and the LLJ ramps up overhead. CAMs have been 
all over the place for thunderstorm progression, ranging anywhere 
from an MCS dropping into northern Iowa to nobody in the forecast 
area seeing a single drop of rainfall. Therefore, without any strong 
forcing mechanism to keep an eye and lack of reliable model 
guidance, confidence is low on how convection will play out tonight. 
Storm prediction will rely heavily on identifying mesoscale features 
and monitoring trends through the day today and into tonight. If an 
MCS were to drop into the state tonight/tomorrow morning, strong 
winds and brief heavy rainfall would be the main severe weather 
concerns, which SPC has highlighted with their day 1 slight risk for 
severe weather across far northeast Iowa. 

The hot and humid conditions continue through Sunday, with slightly 
warmer highs in the low to mid 90s and widespread heat index values 
of 100 to 105F. A heat advisory will likely be needed once again on 
Sunday, but have continued the day by day strategy for issuing 
headlines given the uncertainty of convection tonight and how that 
may affect highs Sunday. The heat dome then begins to break apart on 
Monday, as a cool front pushes the warmer temperatures further 
south. That being said, expecting temperatures on the warm side of 
the front to again be nearing advisory criteria with more high 
temperatures in the 90s on Monday. The extent of these temperatures 
will be contingent on the location of the front on Monday, as well 
as any convection and resultant cloud cover that develops along it. 
Guidance continues to show thunderstorms developing along the 
boundary as it pushes south on Monday, but has backed off on the 
extent of storms further west in the state. This is likely due to 
the warm layer still present along the boundary and large amounts of 
CINH preceding it. That being said, bulk shear values around 30 to 
35 kts and plenty of instability will make Monday worth keeping an 
eye on, especially with PWATs of 2”+ pooling along the front. SPC 
currently has a marginal risk area wide, with a slight risk clipping 
our far northeast.

&&

.AVIATION /18Z TAFS THROUGH 18Z SUNDAY/...
Issued at 1248 PM CDT Sat Jul 13 2024

More expansive MVFR cu field developing along boundary in
northern Iowa; affecting mainly FOD and ALO for now. Some
potential for brief MVFR cu at DSM this afternoon. Projected CAP
at H700 expected to hold, but still uncertain. If cap doesn't
hold, will have an area of storms breaking out somewhere near
US20 corridor by 21 to 02z. CAMS have not handled well past 24
hours, but forcing still struggling over our area. Winds have 
increased with deeper mixing south of boundary at DSM/OTM and 
should continue with gusts nearing 23kt through 23z. Will 
monitor future any convective trends that might occur and update
as needed. /rev

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.

&&

$$

DISCUSSION...Dodson
AVIATION...REV
",AFDDMX,2024-07-13 12:49:00-05,KDMX,FXUS63,
"484 
FXUS63 KDMX 131936
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
236 PM CDT Sat Jul 13 2024

.KEY MESSAGES...

- Heat Advisory in place this Evening and Sunday with some
  expansion of advisory possible Sunday. 
- Highs as warm as lower/mid 90s through Monday
- Some risk of storms north/southeast tonight, Sunday with more
  widespread chances Monday. 

&&

.DISCUSSION...
Issued at 236 PM CDT Sat Jul 13 2024

.Short Term /Tonight through Sunday Night/...

Confidence Short Term:  Medium to High

Main concern this period will be heat and some risk of severe 
weather in the north. Relatively weak sfc features over the region 
at the moment with trough of low pressure in eastern Dakotas south 
to eastern Colorado. Warm front stretches from eastern South Dakota 
to eastern Iowa with an outflow boundary from overnight MN storms 
edging southwest into southern MN this morning. Aloft there is a 
wave reflected at H850/H700 over Nebraska into western Iowa. This 
feature is expected to track east overnight tonight. Somewhat 
complicated mesoscale scenario over the region which is not being 
handled well by any of the CAMS today. While H700 temperatures are 
not capped over eastern Iowa this morning, synoptic models are 
slowly building heat aloft into 12z Sunday with H700 temperatures 
rising to 10 to 13C over the region by 00z and roughly the same 
through 12z. Overall the risk areas for storms will remain the same 
this forecast cycle with northern areas nearer the outflow/warm 
front and the southeast which may benefit from slightly stronger 
forcing overnight into early morning Sunday. This afternoon SBCAPE 
forecast for the north is likely to be 4000 to 5000 j/kg across the 
sfc frontal corridor, though the H700 cap aloft will increase to 
about 11C. At this time, the amount of surface convergence is 
expected to remain low over the north. If the lack of mass convergence
along the boundary continues as forecast, this should lessen the
chances of initiation over northern Iowa. Tonight the steering 
currents will help push any developed convection mainly east 
with time as that and the cap aloft continues to build into the 
region overnight. Highs today have been tracking slightly higher
than forecast in the south and lows tonight will likely be a 
bit warmer over the area as well. There remains some uncertainty
in the southeast overnight tonight with regard to storm development.
Though the CAMS are maintaining little risk of storm development,
the GFS/GEFs and to a lesser degree, the EC/EPS both show some 
development in the southeast. Placement and coverage, though, 
remain rather small. Highs Sunday will get an early boost from 
overnight mins being so warm. By afternoon, highs will once 
again be in the lower to mid 90s with afternoon heat indices in 
the upper 90s to lower 100s. We have gone ahead and issued
another heat advisory in the same areas as today. There may be
a need to expand the advisory farther north/east Sunday. 

.Long Term /Monday through Saturday/...

Confidence: Medium to High

Hot and humid weather will continue Monday with an area more 
restricted to the south. By Monday the front will begin to slip 
south, driven by convection over MN and Iowa. Models differ on 
timing of most coverage, whether 18 to 00z or 00 to 06z but in 
either case there should be a more widespread chance of storms with 
some stronger to severe storms possible, along with brief heavy 
rainfall. The current marginal risk may need to be expanded over the 
area for Monday in future updates. Both the GFS/EC deterministic 
solutions are showing increased shear in the afternoon/evening 
periods Monday. The main difference currently is the H700 cap which 
is stronger, longer in the operational GFS.  The GEFS solution 
supports the more capped GFS while the EPS solution is more 
convective than the GFS suite, while slightly less than the 
operational EC. Will maintain the current blended forecast for 
Monday with scattered storms in the afternoon and evening periods 
over most of the forecast area along the boundary. Highs Monday will 
reach the upper 80s north to the mid 90s south; heat indices 
reaching the upper 90s to lower 100s south of US30. The good news is 
that once the boundary gets pushed south of the area, a Canadian 
high is expected to take up residence over Great Lakes and extend 
into Iowa for much of the remainder of the week. With H850 
temperatures lowering to around 10C from Wednesday to Saturday, 
highs should settle into a mid 70s to lower 80s range.  Tuesday will 
be the transition day, with perhaps a slightly bigger temperature
spread from north to south. 

&&

.AVIATION /18Z TAFS THROUGH 18Z SUNDAY/...
Issued at 1248 PM CDT Sat Jul 13 2024

More expansive MVFR cu field developing along boundary in
northern Iowa; affecting mainly FOD and ALO for now. Some
potential for brief MVFR cu at DSM this afternoon. Projected CAP
at H700 expected to hold, but still uncertain. If cap doesn't
hold, will have an area of storms breaking out somewhere near
US20 corridor by 21 to 02z. CAMS have not handled well past 24
hours, but forcing still struggling over our area. Winds have 
increased with deeper mixing south of boundary at DSM/OTM and 
should continue with gusts nearing 23kt through 23z. Will 
monitor future any convective trends that might occur and update
as needed. /rev

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.
Heat Advisory from 1 PM to 8 PM CDT Sunday for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.

&&

$$

DISCUSSION...REV
AVIATION...REV
",AFDDMX,2024-07-13 14:36:00-05,KDMX,FXUS63,
"333 
FXUS63 KDMX 132351
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
651 PM CDT Sat Jul 13 2024

 ...Updated for the 00z Aviation Discussion...

.KEY MESSAGES...

- Heat Advisory in place this Evening and Sunday with some
  expansion of advisory possible Sunday. 
- Highs as warm as lower/mid 90s through Monday
- Some risk of storms north/southeast tonight, Sunday with more
  widespread chances Monday.

&&

.DISCUSSION...
Issued at 236 PM CDT Sat Jul 13 2024

.Short Term /Tonight through Sunday Night/...

Confidence Short Term:  Medium to High

Main concern this period will be heat and some risk of severe 
weather in the north. Relatively weak sfc features over the region 
at the moment with trough of low pressure in eastern Dakotas south 
to eastern Colorado. Warm front stretches from eastern South Dakota 
to eastern Iowa with an outflow boundary from overnight MN storms 
edging southwest into southern MN this morning. Aloft there is a 
wave reflected at H850/H700 over Nebraska into western Iowa. This 
feature is expected to track east overnight tonight. Somewhat 
complicated mesoscale scenario over the region which is not being 
handled well by any of the CAMS today. While H700 temperatures are 
not capped over eastern Iowa this morning, synoptic models are 
slowly building heat aloft into 12z Sunday with H700 temperatures 
rising to 10 to 13C over the region by 00z and roughly the same 
through 12z. Overall the risk areas for storms will remain the same 
this forecast cycle with northern areas nearer the outflow/warm 
front and the southeast which may benefit from slightly stronger 
forcing overnight into early morning Sunday. This afternoon SBCAPE 
forecast for the north is likely to be 4000 to 5000 j/kg across the 
sfc frontal corridor, though the H700 cap aloft will increase to 
about 11C. At this time, the amount of surface convergence is 
expected to remain low over the north. If the lack of mass convergence
along the boundary continues as forecast, this should lessen the
chances of initiation over northern Iowa. Tonight the steering 
currents will help push any developed convection mainly east 
with time as that and the cap aloft continues to build into the 
region overnight. Highs today have been tracking slightly higher
than forecast in the south and lows tonight will likely be a 
bit warmer over the area as well. There remains some uncertainty
in the southeast overnight tonight with regard to storm development.
Though the CAMS are maintaining little risk of storm development,
the GFS/GEFs and to a lesser degree, the EC/EPS both show some 
development in the southeast. Placement and coverage, though, 
remain rather small. Highs Sunday will get an early boost from 
overnight mins being so warm. By afternoon, highs will once 
again be in the lower to mid 90s with afternoon heat indices in 
the upper 90s to lower 100s. We have gone ahead and issued
another heat advisory in the same areas as today. There may be
a need to expand the advisory farther north/east Sunday. 

.Long Term /Monday through Saturday/...

Confidence: Medium to High

Hot and humid weather will continue Monday with an area more 
restricted to the south. By Monday the front will begin to slip 
south, driven by convection over MN and Iowa. Models differ on 
timing of most coverage, whether 18 to 00z or 00 to 06z but in 
either case there should be a more widespread chance of storms with 
some stronger to severe storms possible, along with brief heavy 
rainfall. The current marginal risk may need to be expanded over the 
area for Monday in future updates. Both the GFS/EC deterministic 
solutions are showing increased shear in the afternoon/evening 
periods Monday. The main difference currently is the H700 cap which 
is stronger, longer in the operational GFS.  The GEFS solution 
supports the more capped GFS while the EPS solution is more 
convective than the GFS suite, while slightly less than the 
operational EC. Will maintain the current blended forecast for 
Monday with scattered storms in the afternoon and evening periods 
over most of the forecast area along the boundary. Highs Monday will 
reach the upper 80s north to the mid 90s south; heat indices 
reaching the upper 90s to lower 100s south of US30. The good news is 
that once the boundary gets pushed south of the area, a Canadian 
high is expected to take up residence over Great Lakes and extend 
into Iowa for much of the remainder of the week. With H850 
temperatures lowering to around 10C from Wednesday to Saturday, 
highs should settle into a mid 70s to lower 80s range.  Tuesday will 
be the transition day, with perhaps a slightly bigger temperature
spread from north to south.

&&

.AVIATION /00Z TAFS THROUGH 00Z MONDAY/...
Issued at 642 PM CDT Sat Jul 13 2024

VFR conditions ongoing early this evening with gusty afternoon
winds expected to subside tonight as winds shift from out of the
southwest to south and then back to southwest tonight into
Sunday morning, with some light and variable winds at times,
especially north. Convective trends remain the complicating
factor this forecast with models continuing to have a difficult
time in handling current storms over southern MN. Have
maintained dry forecast at this point, but will need to watch
especially KMCW if any storms can move into northern/northeast 
Iowa tonight. Some additional storm chances at times into 
Sunday, but CAP appears to hold for the most part. Will continue
to monitor trends and update TAFs as needed. 

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.
Heat Advisory from 1 PM to 8 PM CDT Sunday for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.

&&

$$

DISCUSSION...REV
AVIATION...KCM
",AFDDMX,2024-07-13 18:51:00-05,KDMX,FXUS63,
"448 
FXUS63 KDMX 140514
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1214 AM CDT Sun Jul 14 2024

 ...Updated for the 06z Aviation Discussion...

.KEY MESSAGES...

- Heat Advisory in place this Evening and Sunday with some
  expansion of advisory possible Sunday. 
- Highs as warm as lower/mid 90s through Monday
- Some risk of storms north/southeast tonight, Sunday with more
  widespread chances Monday.

&&

.DISCUSSION...
Issued at 236 PM CDT Sat Jul 13 2024

.Short Term /Tonight through Sunday Night/...

Confidence Short Term:  Medium to High

Main concern this period will be heat and some risk of severe 
weather in the north. Relatively weak sfc features over the region 
at the moment with trough of low pressure in eastern Dakotas south 
to eastern Colorado. Warm front stretches from eastern South Dakota 
to eastern Iowa with an outflow boundary from overnight MN storms 
edging southwest into southern MN this morning. Aloft there is a 
wave reflected at H850/H700 over Nebraska into western Iowa. This 
feature is expected to track east overnight tonight. Somewhat 
complicated mesoscale scenario over the region which is not being 
handled well by any of the CAMS today. While H700 temperatures are 
not capped over eastern Iowa this morning, synoptic models are 
slowly building heat aloft into 12z Sunday with H700 temperatures 
rising to 10 to 13C over the region by 00z and roughly the same 
through 12z. Overall the risk areas for storms will remain the same 
this forecast cycle with northern areas nearer the outflow/warm 
front and the southeast which may benefit from slightly stronger 
forcing overnight into early morning Sunday. This afternoon SBCAPE 
forecast for the north is likely to be 4000 to 5000 j/kg across the 
sfc frontal corridor, though the H700 cap aloft will increase to 
about 11C. At this time, the amount of surface convergence is 
expected to remain low over the north. If the lack of mass convergence
along the boundary continues as forecast, this should lessen the
chances of initiation over northern Iowa. Tonight the steering 
currents will help push any developed convection mainly east 
with time as that and the cap aloft continues to build into the 
region overnight. Highs today have been tracking slightly higher
than forecast in the south and lows tonight will likely be a 
bit warmer over the area as well. There remains some uncertainty
in the southeast overnight tonight with regard to storm development.
Though the CAMS are maintaining little risk of storm development,
the GFS/GEFs and to a lesser degree, the EC/EPS both show some 
development in the southeast. Placement and coverage, though, 
remain rather small. Highs Sunday will get an early boost from 
overnight mins being so warm. By afternoon, highs will once 
again be in the lower to mid 90s with afternoon heat indices in 
the upper 90s to lower 100s. We have gone ahead and issued
another heat advisory in the same areas as today. There may be
a need to expand the advisory farther north/east Sunday. 

.Long Term /Monday through Saturday/...

Confidence: Medium to High

Hot and humid weather will continue Monday with an area more 
restricted to the south. By Monday the front will begin to slip 
south, driven by convection over MN and Iowa. Models differ on 
timing of most coverage, whether 18 to 00z or 00 to 06z but in 
either case there should be a more widespread chance of storms with 
some stronger to severe storms possible, along with brief heavy 
rainfall. The current marginal risk may need to be expanded over the 
area for Monday in future updates. Both the GFS/EC deterministic 
solutions are showing increased shear in the afternoon/evening 
periods Monday. The main difference currently is the H700 cap which 
is stronger, longer in the operational GFS.  The GEFS solution 
supports the more capped GFS while the EPS solution is more 
convective than the GFS suite, while slightly less than the 
operational EC. Will maintain the current blended forecast for 
Monday with scattered storms in the afternoon and evening periods 
over most of the forecast area along the boundary. Highs Monday will 
reach the upper 80s north to the mid 90s south; heat indices 
reaching the upper 90s to lower 100s south of US30. The good news is 
that once the boundary gets pushed south of the area, a Canadian 
high is expected to take up residence over Great Lakes and extend 
into Iowa for much of the remainder of the week. With H850 
temperatures lowering to around 10C from Wednesday to Saturday, 
highs should settle into a mid 70s to lower 80s range.  Tuesday will 
be the transition day, with perhaps a slightly bigger temperature
spread from north to south.

&&

.AVIATION /06Z TAFS THROUGH 06Z MONDAY/...
Issued at 1215 AM CDT Sun Jul 14 2024

Maintained VFR conditions through the period at all terminals,
though there remains a high degree of uncertainty in what, if
any, storms may affect the state. One cluster over central
Minnesota is dropping southeast at this hour and current trends
would keep it likely east of MCW and ALO. Another area of storms
over western South Dakota may reach western Iowa before 
sunrise if it holds together, but any terminal impact would be 
after 12z. Even if storms do not directly move over the state, 
there could still be outflow related wind shifts that may cause 
a variation in wind direction that is not reflected in the 
official forecast later in the day Sunday. Staying with the
assumption of no storms moving into the state, it looks like 
another round of diurnally driven cumulus that could be around 
FL030 starting mid-morning. For now, have capped at SCT, though
Saturday ceilings were in BKN in MVFR and will need to 

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM to 8 PM CDT Sunday for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.

&&

$$

DISCUSSION...REV
AVIATION...Ansorge
",AFDDMX,2024-07-14 00:14:00-05,KDMX,FXUS63,
"593 
FXUS63 KDMX 140856
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
356 AM CDT Sun Jul 14 2024

.KEY MESSAGES...

- Few areas of non-severe storms and gusty winds that may impact
  the area early this morning. 

- Hot and humid conditions continue area-wide today and then
  south again tomorrow, with heat indices of 100 to 105F.

- Shower and thunderstorms chances continue tonight into Monday,
  a few of which could be strong to severe. Gusty winds and
  heavy rainfall will be the main threats with storms.

&&

.DISCUSSION...
Issued at 351 AM CDT Sun Jul 14 2024

We continue to watch multiple areas of convection early this morning 
as weak waves  kick off thunderstorms along the periphery of the 
upper level high in the southwest CONUS. Fortunately, much of the 
convection to the north of the state looks as if it will mostly stay 
to our east and the MCS that produced 80 mph winds previously 
tonight over South Dakota has since weakened as it’s drawn nearer to 
the state, likely due to weaker kinematics ahead of it to keep the 
cold pool in balance, as well as the 12C 700 mb temperatures it 
resides in. We’ve also seen a few storms develop along the leading 
edge of the LLJ in southern IA/northern MO tonight, but these have 
stayed sub-severe. Therefore, barring any additional development 
with the MCS to our west or along the outflow from storms to our 
north, not expecting anything other than a few storms this morning. 
That being said, some gusty winds may accompany these features as 
they move into warm, dry environments. 

In addition to storms lingering into the morning hours, the heat 
will continue to build in today, leading to another hot and humid 
day for much of the state. Observed highs yesterday underperformed 
the forecast by 1 to 3 degrees across the area, likely due to a 
combination of 850 hPa temperatures being a bit cooler than 
expected, as well as some patchy cumulus/shower activity through the 
afternoon hours. Likewise, having the warm layer aloft could be 
limiting how deep of mixing can occur, which would then translate to 
surface temperatures. Fortunately, it seems guidance has picked up 
on the slightly cooler 850 hPa temperatures, which has therefore 
brought NBM highs down a tad from yesterday. On the flip side, 
dewpoints overperformed yesterday, which kept apparent temperatures 
over 100F, albeit still slightly lower than forecast. Keeping these 
trends in mind, have tweaked high temperatures and dewpoints 
slightly, but still anticipating hotter temperatures today with 
slightly better mixing. That being said, the aforementioned MCS and 
additional convection through the morning hours will likely have 
some effect on highs today. Even if the precipitation dissipates 
prior to arriving here, residual cloud cover will still likely drift 
over the state in the morning. Therefore, because of the uncertainty 
with convection today, decided to maintain the same area of counties 
for the heat advisory. 

As we get into tonight, more chances for storms will be possible as 
the upper high begins to break down and the upper trough to the 
north drops down into the region. Guidance is again fairly messy 
with the progression of storms tonight, with convection first 
developing with the better forcing to our north tonight and then 
potentially dropping into the state Monday morning. Confidence is 
low in these storms impacting the forecast area, but the mostly 
likely area would be northern Iowa with strong winds being the main 
concern. Confidence is then higher in the occurrence of convection 
associated with the frontal passage Monday afternoon. These storms 
could be more area wide, but the warm layer aloft will likely 
inhibit widespread storm development. Strong winds will be the 
primary concern with the afternoon storms as well, thanks to the 
high bases and dry low levels. Locally heavy rainfall could 
also become a concern with 2""+ PWATs, but storms should be 
fairly progressive as the front pushes south. A supercell would 
be needed to produce any larger hail, as any small hail will 
melt as it falls. Finally, the tornado threat should be low, as 
LCLs will be around 1500m or higher.


Not to be overshadowed by the storm chances, temperatures on Monday 
will again be quite warm, primarily over southern Iowa where the 
boundary will be arriving a bit later in the day. There’s potential 
for Monday to also be the warmest of the three, with 850 hPa 
temperatures nearing 30C ahead of the front. That being said, 
Monday’s highs will suffer from the same uncertainty of previous 
days and be dependent on both location of the front, as well as any 
convection/outflow boundaries that result from it. Regardless, those 
that avoid these features on Monday could see heat indices exceeding 
105F and potentially even approaching 110F. After Monday, 
temperatures return to more normal values and high pressure overhead 
mellows out the pattern through the week. 

&&

.AVIATION /06Z TAFS THROUGH 06Z MONDAY/...
Issued at 1215 AM CDT Sun Jul 14 2024

Maintained VFR conditions through the period at all terminals,
though there remains a high degree of uncertainty in what, if
any, storms may affect the state. One cluster over central
Minnesota is dropping southeast at this hour and current trends
would keep it likely east of MCW and ALO. Another area of storms
over western South Dakota may reach western Iowa before 
sunrise if it holds together, but any terminal impact would be 
after 12z. Even if storms do not directly move over the state, 
there could still be outflow related wind shifts that may cause 
a variation in wind direction that is not reflected in the 
official forecast later in the day Sunday. Staying with the
assumption of no storms moving into the state, it looks like 
another round of diurnally driven cumulus that could be around 
FL030 starting mid-morning. For now, have capped at SCT, though
Saturday ceilings were in BKN in MVFR and will need to

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ004-015-023-024-033>035-044>048-057>062-070>075-
081>086-092>097.

&&

$$

DISCUSSION...Dodson
AVIATION...Ansorge
",AFDDMX,2024-07-14 03:56:00-05,KDMX,FXUS63,
"516 
FXUS63 KDMX 141111
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
611 AM CDT Sun Jul 14 2024

.KEY MESSAGES...

- Few areas of non-severe storms and gusty winds that may impact
  the area early this morning. 

- Hot and humid conditions continue area-wide today and then
  south again tomorrow, with heat indices of 100 to 105F.

- Shower and thunderstorms chances continue tonight into Monday,
  a few of which could be strong to severe. Gusty winds and
  heavy rainfall will be the main threats with storms.

&&

.UPDATE...
Issued at 550 AM CDT Sun Jul 14 2024

Recent trends in short range guidance, particularly the HRRR and
RAP, have started to indicate thunderstorm development over the
northeastern portions of the forecast area this afternoon and 
evening. These storms will be induced by the remnants of the 
overnight MCS in southern South Dakota, which continues to 
produce isolated thunderstorms and strong winds in northwest 
Iowa/southeast South Dakota this morning. As this feature 
tracks east through the day, it will eventually reach a more 
unstable air mass in northeast IA where cooler temperatures 
aloft may allow for surface based convection to develop. Weak 
low level flow and LCLs around 1000m should help to limit 
tornadic development, barring any stretching along a remnant 
boundary. However, high DCAPE values and large amounts of 
instability will make damaging winds and hail a threat, 
especially if storms can utilize every bit of the marginal 25 to
35 kt bulk shear values. 

&&

.DISCUSSION...
Issued at 351 AM CDT Sun Jul 14 2024

We continue to watch multiple areas of convection early this morning 
as weak waves  kick off thunderstorms along the periphery of the 
upper level high in the southwest CONUS. Fortunately, much of the 
convection to the north of the state looks as if it will mostly stay 
to our east and the MCS that produced 80 mph winds previously 
tonight over South Dakota has since weakened as it’s drawn nearer to 
the state, likely due to weaker kinematics ahead of it to keep the 
cold pool in balance, as well as the 12C 700 mb temperatures it 
resides in. We’ve also seen a few storms develop along the leading 
edge of the LLJ in southern IA/northern MO tonight, but these have 
stayed sub-severe. Therefore, barring any additional development 
with the MCS to our west or along the outflow from storms to our 
north, not expecting anything other than a few storms this morning. 
That being said, some gusty winds may accompany these features as 
they move into warm, dry environments. 

In addition to storms lingering into the morning hours, the heat 
will continue to build in today, leading to another hot and humid 
day for much of the state. Observed highs yesterday underperformed 
the forecast by 1 to 3 degrees across the area, likely due to a 
combination of 850 hPa temperatures being a bit cooler than 
expected, as well as some patchy cumulus/shower activity through the 
afternoon hours. Likewise, having the warm layer aloft could be 
limiting how deep of mixing can occur, which would then translate to 
surface temperatures. Fortunately, it seems guidance has picked up 
on the slightly cooler 850 hPa temperatures, which has therefore 
brought NBM highs down a tad from yesterday. On the flip side, 
dewpoints overperformed yesterday, which kept apparent temperatures 
over 100F, albeit still slightly lower than forecast. Keeping these 
trends in mind, have tweaked high temperatures and dewpoints 
slightly, but still anticipating hotter temperatures today with 
slightly better mixing. That being said, the aforementioned MCS and 
additional convection through the morning hours will likely have 
some effect on highs today. Even if the precipitation dissipates 
prior to arriving here, residual cloud cover will still likely drift 
over the state in the morning. Therefore, because of the uncertainty 
with convection today, decided to maintain the same area of counties 
for the heat advisory. 

As we get into tonight, more chances for storms will be possible as 
the upper high begins to break down and the upper trough to the 
north drops down into the region. Guidance is again fairly messy 
with the progression of storms tonight, with convection first 
developing with the better forcing to our north tonight and then 
potentially dropping into the state Monday morning. Confidence is 
low in these storms impacting the forecast area, but the mostly 
likely area would be northern Iowa with strong winds being the main 
concern. Confidence is then higher in the occurrence of convection 
associated with the frontal passage Monday afternoon. These storms 
could be more area wide, but the warm layer aloft will likely 
inhibit widespread storm development. Strong winds will be the 
primary concern with the afternoon storms as well, thanks to the 
high bases and dry low levels. Locally heavy rainfall could 
also become a concern with 2""+ PWATs, but storms should be 
fairly progressive as the front pushes south. A supercell would 
be needed to produce any larger hail, as any small hail will 
melt as it falls. Finally, the tornado threat should be low, as 
LCLs will be around 1500m or higher.


Not to be overshadowed by the storm chances, temperatures on Monday 
will again be quite warm, primarily over southern Iowa where the 
boundary will be arriving a bit later in the day. There’s potential 
for Monday to also be the warmest of the three, with 850 hPa 
temperatures nearing 30C ahead of the front. That being said, 
Monday’s highs will suffer from the same uncertainty of previous 
days and be dependent on both location of the front, as well as any 
convection/outflow boundaries that result from it. Regardless, those 
that avoid these features on Monday could see heat indices exceeding 
105F and potentially even approaching 110F. After Monday, 
temperatures return to more normal values and high pressure overhead 
mellows out the pattern through the week.

&&

.AVIATION /06Z TAFS THROUGH 06Z MONDAY/...
Issued at 1215 AM CDT Sun Jul 14 2024

Maintained VFR conditions through the period at all terminals,
though there remains a high degree of uncertainty in what, if
any, storms may affect the state. One cluster over central
Minnesota is dropping southeast at this hour and current trends
would keep it likely east of MCW and ALO. Another area of storms
over western South Dakota may reach western Iowa before 
sunrise if it holds together, but any terminal impact would be 
after 12z. Even if storms do not directly move over the state, 
there could still be outflow related wind shifts that may cause 
a variation in wind direction that is not reflected in the 
official forecast later in the day Sunday. Staying with the
assumption of no storms moving into the state, it looks like 
another round of diurnally driven cumulus that could be around 
FL030 starting mid-morning. For now, have capped at SCT, though
Saturday ceilings were in BKN in MVFR and will need to

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ004-015-023-024-033>035-044>048-057>062-070>075-
081>086-092>097.

&&

$$

UPDATE...Dodson
DISCUSSION...Dodson
AVIATION...Ansorge
",AFDDMX,2024-07-14 06:11:00-05,KDMX,FXUS63,
"575 
FXUS63 KDMX 141141
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
641 AM CDT Sun Jul 14 2024

 ...Updated for the 12z Aviation Discussion...

.KEY MESSAGES...

- Few areas of non-severe storms and gusty winds that may impact
  the area early this morning. 

- Hot and humid conditions continue area-wide today and then
  south again tomorrow, with heat indices of 100 to 105F.

- Shower and thunderstorms chances continue tonight into Monday,
  a few of which could be strong to severe. Gusty winds and
  heavy rainfall will be the main threats with storms.

&&

.UPDATE...
Issued at 550 AM CDT Sun Jul 14 2024

Recent trends in short range guidance, particularly the HRRR and
RAP, have started to indicate thunderstorm development over the
northeastern portions of the forecast area this afternoon and 
evening. These storms will be induced by the remnants of the 
overnight MCS in southern South Dakota, which continues to 
produce isolated thunderstorms and strong winds in northwest 
Iowa/southeast South Dakota this morning. As this feature 
tracks east through the day, it will eventually reach a more 
unstable air mass in northeast IA where cooler temperatures 
aloft may allow for surface based convection to develop. Weak 
low level flow and LCLs around 1000m should help to limit 
tornadic development, barring any stretching along a remnant 
boundary. However, high DCAPE values and large amounts of 
instability will make damaging winds and hail a threat, 
especially if storms can utilize every bit of the marginal 25 to
35 kt bulk shear values.

&&

.DISCUSSION...
Issued at 351 AM CDT Sun Jul 14 2024

We continue to watch multiple areas of convection early this morning 
as weak waves  kick off thunderstorms along the periphery of the 
upper level high in the southwest CONUS. Fortunately, much of the 
convection to the north of the state looks as if it will mostly stay 
to our east and the MCS that produced 80 mph winds previously 
tonight over South Dakota has since weakened as it’s drawn nearer to 
the state, likely due to weaker kinematics ahead of it to keep the 
cold pool in balance, as well as the 12C 700 mb temperatures it 
resides in. We’ve also seen a few storms develop along the leading 
edge of the LLJ in southern IA/northern MO tonight, but these have 
stayed sub-severe. Therefore, barring any additional development 
with the MCS to our west or along the outflow from storms to our 
north, not expecting anything other than a few storms this morning. 
That being said, some gusty winds may accompany these features as 
they move into warm, dry environments. 

In addition to storms lingering into the morning hours, the heat 
will continue to build in today, leading to another hot and humid 
day for much of the state. Observed highs yesterday underperformed 
the forecast by 1 to 3 degrees across the area, likely due to a 
combination of 850 hPa temperatures being a bit cooler than 
expected, as well as some patchy cumulus/shower activity through the 
afternoon hours. Likewise, having the warm layer aloft could be 
limiting how deep of mixing can occur, which would then translate to 
surface temperatures. Fortunately, it seems guidance has picked up 
on the slightly cooler 850 hPa temperatures, which has therefore 
brought NBM highs down a tad from yesterday. On the flip side, 
dewpoints overperformed yesterday, which kept apparent temperatures 
over 100F, albeit still slightly lower than forecast. Keeping these 
trends in mind, have tweaked high temperatures and dewpoints 
slightly, but still anticipating hotter temperatures today with 
slightly better mixing. That being said, the aforementioned MCS and 
additional convection through the morning hours will likely have 
some effect on highs today. Even if the precipitation dissipates 
prior to arriving here, residual cloud cover will still likely drift 
over the state in the morning. Therefore, because of the uncertainty 
with convection today, decided to maintain the same area of counties 
for the heat advisory. 

As we get into tonight, more chances for storms will be possible as 
the upper high begins to break down and the upper trough to the 
north drops down into the region. Guidance is again fairly messy 
with the progression of storms tonight, with convection first 
developing with the better forcing to our north tonight and then 
potentially dropping into the state Monday morning. Confidence is 
low in these storms impacting the forecast area, but the mostly 
likely area would be northern Iowa with strong winds being the main 
concern. Confidence is then higher in the occurrence of convection 
associated with the frontal passage Monday afternoon. These storms 
could be more area wide, but the warm layer aloft will likely 
inhibit widespread storm development. Strong winds will be the 
primary concern with the afternoon storms as well, thanks to the 
high bases and dry low levels. Locally heavy rainfall could 
also become a concern with 2""+ PWATs, but storms should be 
fairly progressive as the front pushes south. A supercell would 
be needed to produce any larger hail, as any small hail will 
melt as it falls. Finally, the tornado threat should be low, as 
LCLs will be around 1500m or higher.


Not to be overshadowed by the storm chances, temperatures on Monday 
will again be quite warm, primarily over southern Iowa where the 
boundary will be arriving a bit later in the day. There’s potential 
for Monday to also be the warmest of the three, with 850 hPa 
temperatures nearing 30C ahead of the front. That being said, 
Monday’s highs will suffer from the same uncertainty of previous 
days and be dependent on both location of the front, as well as any 
convection/outflow boundaries that result from it. Regardless, those 
that avoid these features on Monday could see heat indices exceeding 
105F and potentially even approaching 110F. After Monday, 
temperatures return to more normal values and high pressure overhead 
mellows out the pattern through the week.

&&

.AVIATION /12Z TAFS THROUGH 12Z MONDAY/...
Issued at 636 AM CDT Sun Jul 14 2024

There's quite a lot going on across the area this morning, with
multiple areas of showers and thunderstorms producing low cigs
and sporadic wind gusts. First, the area thunderstorms and
associated outflow in northwest Iowa will continue south and
east, likely impacting KFOD and KDSM. This will likely bring
a brief increase to winds as well as shift to northwesterly. Low
clouds may also accompany, but confidence is low. The other area
of storms is over KALO and KMCW, which is also producing gusty
north northeasterly winds and low cloud cover. The cloud cover
should improve, but breezy winds could linger. 

As we get further into the day, convection is expected to
diminish, but redevelopment is possible in the afternoon, mainly
at KALO. Storms will be scattered and location of development is
tricky, so have just included VCSH for the most likely period at
KALO and will amend if need be. Elsewhere, skies should clear
some through the day with light to breezy winds across the
south. Additional storms are possible north overnight and into
tomorrow morning, but have left these out of TAFs for now.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ004-015-023-024-033>035-044>048-057>062-070>075-
081>086-092>097.

&&

$$

UPDATE...Dodson
DISCUSSION...Dodson
AVIATION...Dodson
",AFDDMX,2024-07-14 06:41:00-05,KDMX,FXUS63,
"454 
FXUS63 KDMX 141801
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
101 PM CDT Sun Jul 14 2024

 ...Updated for the 18z Aviation Discussion...

.KEY MESSAGES...

- Few areas of non-severe storms and gusty winds that may impact
  the area early this morning. 

- Hot and humid conditions continue area-wide today and then
  south again tomorrow, with heat indices of 100 to 105F.

- Shower and thunderstorms chances continue tonight into Monday,
  a few of which could be strong to severe. Gusty winds and
  heavy rainfall will be the main threats with storms.

&&

.UPDATE...
Issued at 550 AM CDT Sun Jul 14 2024

Recent trends in short range guidance, particularly the HRRR and
RAP, have started to indicate thunderstorm development over the
northeastern portions of the forecast area this afternoon and 
evening. These storms will be induced by the remnants of the 
overnight MCS in southern South Dakota, which continues to 
produce isolated thunderstorms and strong winds in northwest 
Iowa/southeast South Dakota this morning. As this feature 
tracks east through the day, it will eventually reach a more 
unstable air mass in northeast IA where cooler temperatures 
aloft may allow for surface based convection to develop. Weak 
low level flow and LCLs around 1000m should help to limit 
tornadic development, barring any stretching along a remnant 
boundary. However, high DCAPE values and large amounts of 
instability will make damaging winds and hail a threat, 
especially if storms can utilize every bit of the marginal 25 to
35 kt bulk shear values.

&&

.DISCUSSION...
Issued at 351 AM CDT Sun Jul 14 2024

We continue to watch multiple areas of convection early this morning 
as weak waves  kick off thunderstorms along the periphery of the 
upper level high in the southwest CONUS. Fortunately, much of the 
convection to the north of the state looks as if it will mostly stay 
to our east and the MCS that produced 80 mph winds previously 
tonight over South Dakota has since weakened as it’s drawn nearer to 
the state, likely due to weaker kinematics ahead of it to keep the 
cold pool in balance, as well as the 12C 700 mb temperatures it 
resides in. We’ve also seen a few storms develop along the leading 
edge of the LLJ in southern IA/northern MO tonight, but these have 
stayed sub-severe. Therefore, barring any additional development 
with the MCS to our west or along the outflow from storms to our 
north, not expecting anything other than a few storms this morning. 
That being said, some gusty winds may accompany these features as 
they move into warm, dry environments. 

In addition to storms lingering into the morning hours, the heat 
will continue to build in today, leading to another hot and humid 
day for much of the state. Observed highs yesterday underperformed 
the forecast by 1 to 3 degrees across the area, likely due to a 
combination of 850 hPa temperatures being a bit cooler than 
expected, as well as some patchy cumulus/shower activity through the 
afternoon hours. Likewise, having the warm layer aloft could be 
limiting how deep of mixing can occur, which would then translate to 
surface temperatures. Fortunately, it seems guidance has picked up 
on the slightly cooler 850 hPa temperatures, which has therefore 
brought NBM highs down a tad from yesterday. On the flip side, 
dewpoints over performed yesterday, which kept apparent 
temperatures over 100F, albeit still slightly lower than 
forecast. Keeping these trends in mind, have tweaked high 
temperatures and dewpoints slightly, but still anticipating 
hotter temperatures today with slightly better mixing. That 
being said, the aforementioned MCS and additional convection 
through the morning hours will likely have some effect on highs 
today. Even if the precipitation dissipates prior to arriving 
here, residual cloud cover will still likely drift over the 
state in the morning. Therefore, because of the uncertainty with
convection today, decided to maintain the same area of counties
for the heat advisory. 

As we get into tonight, more chances for storms will be possible as 
the upper high begins to break down and the upper trough to the 
north drops down into the region. Guidance is again fairly messy 
with the progression of storms tonight, with convection first 
developing with the better forcing to our north tonight and then 
potentially dropping into the state Monday morning. Confidence is 
low in these storms impacting the forecast area, but the mostly 
likely area would be northern Iowa with strong winds being the main 
concern. Confidence is then higher in the occurrence of convection 
associated with the frontal passage Monday afternoon. These storms 
could be more area wide, but the warm layer aloft will likely 
inhibit widespread storm development. Strong winds will be the 
primary concern with the afternoon storms as well, thanks to the 
high bases and dry low levels. Locally heavy rainfall could 
also become a concern with 2""+ PWATs, but storms should be 
fairly progressive as the front pushes south. A supercell would 
be needed to produce any larger hail, as any small hail will 
melt as it falls. Finally, the tornado threat should be low, as 
LCLs will be around 1500m or higher.


Not to be overshadowed by the storm chances, temperatures on Monday 
will again be quite warm, primarily over southern Iowa where the 
boundary will be arriving a bit later in the day. There’s potential 
for Monday to also be the warmest of the three, with 850 hPa 
temperatures nearing 30C ahead of the front. That being said, 
Monday’s highs will suffer from the same uncertainty of previous 
days and be dependent on both location of the front, as well as any 
convection/outflow boundaries that result from it. Regardless, those 
that avoid these features on Monday could see heat indices exceeding 
105F and potentially even approaching 110F. After Monday, 
temperatures return to more normal values and high pressure overhead 
mellows out the pattern through the week.

&&

.AVIATION /18Z TAFS THROUGH 18Z MONDAY/...
Issued at 1259 PM CDT Sun Jul 14 2024

MCV and lower MVFR cigs over northern areas this afternoon may
still spark some convection between 21 to 00z. Otherwise, next
up will be another MCS spreading southeast from the Dakotas into
southeast MN by 12z. This should impact MCW and possibly ALO
with scattered showers/storms prior to 14z. Tomorrow, though
uncertain, may see a strong convective bowing system somewhere 
between I80 and US20 sometime late morning and maturing aft 18z.
Please monitor later forecasts/SPC updates for additional
information.  /rev


&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.

&&

$$

UPDATE...Dodson
DISCUSSION...Dodson
AVIATION...REV
",AFDDMX,2024-07-14 13:01:00-05,KDMX,FXUS63,
"084 
FXUS63 KDMX 141952
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
252 PM CDT Sun Jul 14 2024

.KEY MESSAGES...

- Enhanced Severe Storm Risk Monday with potential of 
  significant damaging wind gusts over 70 mph 
- Heat Advisory in place to this Evening and Monday South 
- Cooler and Mainly Dry Tuesday through Sunday

&&

.DISCUSSION...
Issued at 252 PM CDT Sun Jul 14 2024

.Short Term /Tonight through Monday Night/...

Confidence Short Term: Low to Medium

Several competing factors in the short term forecast again this 
period with regard to precip chances.  Heat remains the constant for 
now, though debris clouds from leftover convection will modulate 
highs a bit again today in some areas. Weak synoptic surface 
features remain over the region. Aloft at H700, the leading edge of 
the cap of 10C was over eastern Iowa at 12z. This did allow the two 
MCS to increase in strength around sunrise as they reached the 
eastern extent of the H700 cap. The approaching wave/MCS from South 
Dakota has now entered the region of warmer air aloft and 
correspondingly diminished over northern Iowa as anticipated. By 
this afternoon, some increase in storm coverage is expected as the 
H700 wave over the Northern Plains tracks east into Iowa this 
evening and crosses the state overnight.  The synoptic models 
(EC/GFS) are holding the H700 cap over Iowa through the overnight. 
CAMS, particularly the HRRR and ARW cores are showing some weakness 
in the cap again over eastern Iowa by 21-23z this afternoon. Though 
no solution is heavily favored over the other, we will keep some 
thunder chances this afternoon over the northeast along the US20 to 
US30 corridors. Tonight the main areas of convection should hold 
north of Iowa until late in the period when some storms may cross 
into northern Iowa prior to sunrise as a stronger MCS moves through 
southern Minnesota and Wisconsin. Lows tonight will fall to the 
upper 60s to lower 70s in the north while the central to south will 
remain in the mid 70s. Tomorrow lingering debris clouds north and 
the sagging surface boundary will hold temperatures in the 80s north 
while the south again will be in the 90s with heat indices in the 
100s.  Tomorrow will be similar to today with regard to timing out 
convection. We will still be battling the H700 cap for a portion of 
the day into the afternoon hours. The main difference tomorrow is 
the added surface moisture convergence along the boundary moving 
through the region, plus increasing shear during the day and 
afternoon. CAMS are now showing some earlier initiation with late 
morning into early/mid afternoon firing of convection along the
sagging boundary into central Iowa. Upper level wind fields are
looking more favorable for a potential severe bowing system 
with more significant damaging thunderstorm winds into the 
afternoon hours. Still a fair amount of uncertainty with 
initiation and placement, but a corridor between US20/I80 and 
around or slightly east of I35 is more favored at this time. SPC
is upgrading SWODY2 to enhanced over central to eastern Iowa 
with this potential in mind. Will need to monitor trends 
overnight into early Monday morning with regard to outflow,
approaching upper level system and model convective trends. 
After the main area of early afternoon convection exits the 
region, we will still see trailing convection along the boundary in
the evening into overnight hours south as the front sags into 
northern Missouri. With upper level return flow over the boundary,
more storms will be possible through Tuesday 12z in this area. 
Lows Monday night will fall to the lower 60s north to the lower 
70s in the south.

.Long Term /Tuesday through Sunday/...

Confidence: Medium to High

After tomorrow's potential significant convection, we will get a 
welcomed break from storms, heat and humidity through the end of the 
period.  Still looking on track for highs to cool to the 70s to 
lower 80s with lows in the 50s to lower 60s for much of next week. 
There is some uncertainty late in the period with regard to return 
moisture, but some showers may advance back into western section 
around next Sunday. 

&&

.AVIATION /18Z TAFS THROUGH 18Z MONDAY/...
Issued at 1259 PM CDT Sun Jul 14 2024

MCV and lower MVFR cigs over northern areas this afternoon may
still spark some convection between 21 to 00z. Otherwise, next
up will be another MCS spreading southeast from the Dakotas into
southeast MN by 12z. This should impact MCW and possibly ALO
with scattered showers/storms prior to 14z. Tomorrow, though
uncertain, may see a strong convective bowing system somewhere 
between I80 and US20 sometime late morning and maturing aft 18z.
Please monitor later forecasts/SPC updates for additional
information.  /rev

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.
Heat Advisory from 1 PM to 8 PM CDT Monday for IAZ057>062-
070>075-081>086-092>097.

&&

$$

DISCUSSION...REV 
AVIATION...REV
",AFDDMX,2024-07-14 14:52:00-05,KDMX,FXUS63,
"089 
FXUS63 KDMX 142344
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
644 PM CDT Sun Jul 14 2024

 ...Updated for the 00z Aviation Discussion...

.KEY MESSAGES...

- Enhanced Severe Storm Risk Monday with potential of 
  significant damaging wind gusts over 70 mph 
- Heat Advisory in place to this Evening and Monday South 
- Cooler and Mainly Dry Tuesday through Sunday

&&

.DISCUSSION...
Issued at 252 PM CDT Sun Jul 14 2024

.Short Term /Tonight through Monday Night/...

Confidence Short Term: Low to Medium

Several competing factors in the short term forecast again this 
period with regard to precip chances.  Heat remains the constant for 
now, though debris clouds from leftover convection will modulate 
highs a bit again today in some areas. Weak synoptic surface 
features remain over the region. Aloft at H700, the leading edge of 
the cap of 10C was over eastern Iowa at 12z. This did allow the two 
MCS to increase in strength around sunrise as they reached the 
eastern extent of the H700 cap. The approaching wave/MCS from South 
Dakota has now entered the region of warmer air aloft and 
correspondingly diminished over northern Iowa as anticipated. By 
this afternoon, some increase in storm coverage is expected as the 
H700 wave over the Northern Plains tracks east into Iowa this 
evening and crosses the state overnight.  The synoptic models 
(EC/GFS) are holding the H700 cap over Iowa through the overnight. 
CAMS, particularly the HRRR and ARW cores are showing some weakness 
in the cap again over eastern Iowa by 21-23z this afternoon. Though 
no solution is heavily favored over the other, we will keep some 
thunder chances this afternoon over the northeast along the US20 to 
US30 corridors. Tonight the main areas of convection should hold 
north of Iowa until late in the period when some storms may cross 
into northern Iowa prior to sunrise as a stronger MCS moves through 
southern Minnesota and Wisconsin. Lows tonight will fall to the 
upper 60s to lower 70s in the north while the central to south will 
remain in the mid 70s. Tomorrow lingering debris clouds north and 
the sagging surface boundary will hold temperatures in the 80s north 
while the south again will be in the 90s with heat indices in the 
100s.  Tomorrow will be similar to today with regard to timing out 
convection. We will still be battling the H700 cap for a portion of 
the day into the afternoon hours. The main difference tomorrow is 
the added surface moisture convergence along the boundary moving 
through the region, plus increasing shear during the day and 
afternoon. CAMS are now showing some earlier initiation with late 
morning into early/mid afternoon firing of convection along the
sagging boundary into central Iowa. Upper level wind fields are
looking more favorable for a potential severe bowing system 
with more significant damaging thunderstorm winds into the 
afternoon hours. Still a fair amount of uncertainty with 
initiation and placement, but a corridor between US20/I80 and 
around or slightly east of I35 is more favored at this time. SPC
is upgrading SWODY2 to enhanced over central to eastern Iowa 
with this potential in mind. Will need to monitor trends 
overnight into early Monday morning with regard to outflow,
approaching upper level system and model convective trends. 
After the main area of early afternoon convection exits the 
region, we will still see trailing convection along the boundary in
the evening into overnight hours south as the front sags into 
northern Missouri. With upper level return flow over the boundary,
more storms will be possible through Tuesday 12z in this area. 
Lows Monday night will fall to the lower 60s north to the lower 
70s in the south.

.Long Term /Tuesday through Sunday/...

Confidence: Medium to High

After tomorrow's potential significant convection, we will get a 
welcomed break from storms, heat and humidity through the end of the 
period.  Still looking on track for highs to cool to the 70s to 
lower 80s with lows in the 50s to lower 60s for much of next week. 
There is some uncertainty late in the period with regard to return 
moisture, but some showers may advance back into western section 
around next Sunday.

&&

.AVIATION /00Z TAFS THROUGH 00Z TUESDAY/...
Issued at 644 PM CDT Sun Jul 14 2024

A cluster of thunderstorms this evening is impacting KALO. While
precipitation will pass near to just south of the terminal,
lighting will be a threat for the next hour. Activity this
evening should remain clear of other TAF sites. Confidence
decreases on Monday morning as there is the potential for 
convection across northern and eastern terminals. Timing and
location have been difficult to pin down and will depend greatly
on how the current storms in Iowa and overnight convection
across the midwest play out. Therefore have kept to VCTS
mentions and will need to update later as confidence increases
in the details.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ004-015-023-
024-033>035-044>048-057>062-070>075-081>086-092>097.
Heat Advisory from 1 PM to 8 PM CDT Monday for IAZ057>062-
070>075-081>086-092>097.

&&

$$

DISCUSSION...REV 
AVIATION...Hagenhoff
",AFDDMX,2024-07-14 18:44:00-05,KDMX,FXUS63,
"153 
FXUS63 KDMX 150510
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1210 AM CDT Mon Jul 15 2024

 ...Updated for the 06z Aviation Discussion...

.KEY MESSAGES...

- Enhanced Severe Storm Risk Monday with potential of 
  significant damaging wind gusts over 70 mph 
- Heat Advisory in place to this Evening and Monday South 
- Cooler and Mainly Dry Tuesday through Sunday

&&

.DISCUSSION...
Issued at 252 PM CDT Sun Jul 14 2024

.Short Term /Tonight through Monday Night/...

Confidence Short Term: Low to Medium

Several competing factors in the short term forecast again this 
period with regard to precip chances.  Heat remains the constant for 
now, though debris clouds from leftover convection will modulate 
highs a bit again today in some areas. Weak synoptic surface 
features remain over the region. Aloft at H700, the leading edge of 
the cap of 10C was over eastern Iowa at 12z. This did allow the two 
MCS to increase in strength around sunrise as they reached the 
eastern extent of the H700 cap. The approaching wave/MCS from South 
Dakota has now entered the region of warmer air aloft and 
correspondingly diminished over northern Iowa as anticipated. By 
this afternoon, some increase in storm coverage is expected as the 
H700 wave over the Northern Plains tracks east into Iowa this 
evening and crosses the state overnight.  The synoptic models 
(EC/GFS) are holding the H700 cap over Iowa through the overnight. 
CAMS, particularly the HRRR and ARW cores are showing some weakness 
in the cap again over eastern Iowa by 21-23z this afternoon. Though 
no solution is heavily favored over the other, we will keep some 
thunder chances this afternoon over the northeast along the US20 to 
US30 corridors. Tonight the main areas of convection should hold 
north of Iowa until late in the period when some storms may cross 
into northern Iowa prior to sunrise as a stronger MCS moves through 
southern Minnesota and Wisconsin. Lows tonight will fall to the 
upper 60s to lower 70s in the north while the central to south will 
remain in the mid 70s. Tomorrow lingering debris clouds north and 
the sagging surface boundary will hold temperatures in the 80s north 
while the south again will be in the 90s with heat indices in the 
100s.  Tomorrow will be similar to today with regard to timing out 
convection. We will still be battling the H700 cap for a portion of 
the day into the afternoon hours. The main difference tomorrow is 
the added surface moisture convergence along the boundary moving 
through the region, plus increasing shear during the day and 
afternoon. CAMS are now showing some earlier initiation with late 
morning into early/mid afternoon firing of convection along the
sagging boundary into central Iowa. Upper level wind fields are
looking more favorable for a potential severe bowing system 
with more significant damaging thunderstorm winds into the 
afternoon hours. Still a fair amount of uncertainty with 
initiation and placement, but a corridor between US20/I80 and 
around or slightly east of I35 is more favored at this time. SPC
is upgrading SWODY2 to enhanced over central to eastern Iowa 
with this potential in mind. Will need to monitor trends 
overnight into early Monday morning with regard to outflow,
approaching upper level system and model convective trends. 
After the main area of early afternoon convection exits the 
region, we will still see trailing convection along the boundary in
the evening into overnight hours south as the front sags into 
northern Missouri. With upper level return flow over the boundary,
more storms will be possible through Tuesday 12z in this area. 
Lows Monday night will fall to the lower 60s north to the lower 
70s in the south.

.Long Term /Tuesday through Sunday/...

Confidence: Medium to High

After tomorrow's potential significant convection, we will get a 
welcomed break from storms, heat and humidity through the end of the 
period.  Still looking on track for highs to cool to the 70s to 
lower 80s with lows in the 50s to lower 60s for much of next week. 
There is some uncertainty late in the period with regard to return 
moisture, but some showers may advance back into western section 
around next Sunday.

&&

.AVIATION /06Z TAFS THROUGH 06Z TUESDAY/...
Issued at 1205 AM CDT Mon Jul 15 2024

Fog is anticipated to develop over KMCW and KALO in the early
morning with IFR restrictions possible until sunrise.
Thunderstorms expected throughout the day, although location and
severity remains at low confidence. Have included VCTS to
reflect window of highest confidence for each site. KMCW to have
storms nearby in the morning, but confidence is low in their
sustainability as they sink into the state so left out of KALO
and KFOD for now. Secondary storms are possible for the rest of
sites in the afternoon, primarily after 20z. Will continue to
refine timing with upcoming issuances. Important to note that
storms may be severe with high winds in excess of 50kts possible
throughout the day.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ057>062-070>075-081>086-092>097.

&&

$$

DISCUSSION...REV
AVIATION...Jimenez
",AFDDMX,2024-07-15 00:10:00-05,KDMX,FXUS63,
"763 
FXUS63 KDMX 150918
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
418 AM CDT Mon Jul 15 2024

.KEY MESSAGES...

- A few strong storms are possible this morning with additional
  development expected again this afternoon and into the early
  evening. Severe weather is likely with any storms that develop
  today, with damaging wind gusts the primary concern.
 
- Hot and humid temperatures continue south today, with heat
  index values over 105F possible. 

- Quieter conditions with the return of more seasonal
  temperatures through the remainder of the week. 


&&

.DISCUSSION...
Issued at 414 AM CDT Mon Jul 15 2024

Our upper level ridge to the southwest remains in place early Monday 
morning but an upper trough has begun to dig south into the northern 
plains region. The resultant forcing has produced convection 
currently over eastern North Dakota/western Minnesota at the time of 
writing. This complex of storms will bring the first possibility for 
storms in the area today as the MCS makes it’s way south southeast 
through Minnesota and potentially into northern Iowa later this 
morning. The current expectation is for this to roughly follow the 
edge of the more capped air but remain rooted to the LLJ and 
associated theta-e advection wing. Therefore, if the MCS can sustain 
itself along this path, it would arrive in the far north to 
northeastern portions of the area later this morning, with damaging 
winds being the greatest concern. However, recent trends in model 
guidance have been for this complex to weaken as it nears the state, 
likely as it loses support from the LLJ in the morning and succumbs 
to the warmer air aloft. If this scenario plays out, the MCS itself 
would not be of immediate concern, but it’s remnants (whether that 
be an outflow boundary or an MCV), would be a potential point for re-
development as they pass through less capped air over northeast Iowa 
this morning. With plenty of instability present and improving wind 
fields allowing for a more favorable shear environment today, any of 
this redevelopment could become severe, with strong winds still 
being the primary area of concern. If it’s not already apparent from 
the scenarios laid out above, confidence in the morning convective 
trends is low, and it’s certainly also a possibility for the 
forecast area to remain dry through the morning hours. 

CAMs continue to struggle with how convective trends will play out 
into the afternoon as well, and it’d be nearly impossible to hone in 
on any one solution. Therefore, instead of trying to get surgical 
with saying one model run is better than another, we’ll focus on the 
features present and the potential scenarios that may result. As we 
move through the day, the trough digs further south with a surface 
boundary arriving in northern Iowa around 17 to 18z then tracking 
through the area and departing to the south in the evening around 04 
to 05z. This boundary will be the primary focal point for additional 
storm development today, especially as we progress into the 
afternoon and the warm layer aloft begins to mix out. The initial 
development will favor areas further east where temperatures aloft 
are cooler, while areas further west will rely on erosion of the 
warm layer aloft to produce storms, likely later in the day and 
further south. Guidance indicates that the boundary may also slow 
down some as it reaches southern Iowa, which could lead to brief 
periods of training storms over southern Iowa. Based on this 
expected progression, anticipating that the most favorable areas for 
storms will initially be further north and east in the early 
afternoon hours, with increasing chances slightly further west and 
in the southern portions of Iowa by late afternoon and evening. Of 
course, this is the expected scenario. Failure modes/alternate 
scenarios would include convection developing west along the nose of 
the LLJ in the morning hours and tracking east through the area, a 
faster/slower eroding cap allowing for more/less storms further 
north and west, and outflow boundaries producing convection ahead of 
the synoptic front. 

The environment available to storms out ahead of the boundary is 
quite favorable for severe weather. MLCAPE values are around 3000 to 
4000 J/kg or higher, and stronger midlevel winds ahead of the upper 
trough will allow for 0-6 km bulk shear values of 40 to 50 kts. 
Moisture will be plentiful as well, with warm, moist air pooling 
along the boundary resulting in PWATs up to 2.5” or more in some 
locations. Therefore, any storms that fire will become organized and 
have the ability to produce efficient rainfall. However, despite the 
moisture present within the profile, relatively dry conditions will 
be in place at the lower levels thanks to the abnormally warm air in 
place over the state. Therefore, DCAPE values of 1000 to 1500 J/kg 
are expected with cold pool development likely. This, in conjunction 
with the strong shear, will promote upscale growth of initially 
discrete storms as they congeal into an MCS, making damaging winds a 
strong concern for today. Storm motions will generally be to the 
east, which will be along to slightly south of the boundary 
orientation. This would suggest the possibility for cell mergers and 
ingestion of any boundaries produced by convection further east, 
which could locally amplify wind gusts within the MCS. Therefore, 
not completely out of the realm of possibility to see winds nearing 
70kts with these storms, and could potentially see some localized 
wind gusts even higher than that. That being said, with convective 
initiation favoring the eastern portions of the area and the 30 to 
35 kt storm motions, storms may depart the area prior to reaching 
peak intensity, which  echoes both the SPC and machine learning 
severe probabilities that favor the eastern portions of the area. 
Regardless, this will all depend on where storms initiate and grow 
upscale. 

In addition to strong winds, hail is possible initially with any 
discrete convection, but will  become less likely as the storm 
transitions to a linear mode. Similarly, a tornado or two cannot be 
ruled out, whether that be with a rotating discrete storm, or with 
any embedded QLCS tornadoes that may develop. The 0-3 km bulk shear 
will be borderline around 25 to 30 kts, but there will be plenty of 
stretching, so will need to monitor for mesovortex development along 
any MCSs as well. SPC has maintained the enhanced risk for severe 
weather over the eastern portions of our forecast area and into 
eastern Iowa, with a risk for significant winds over the same area. 
This all being said, want to once again stress the uncertainty in 
location and evolution of storms today and into this evening. While 
the environment is primed, there are a lot of factors that could 
influence storms today. Therefore, our recommendation is to prepare 
as if your area could see significant weather, but bear in mind that 
some may see little to no storms at all. 

Finally, not to be forgotten with the severe weather expected today, 
temperatures will once again be hot and humid, mainly over southern 
Iowa where the boundary won't reach until late in the day. With 
850mb temperatures in the upper 20s to near 30 celsius, this looks 
like it could be the warmest day of the past couple for those in the 
southern half of Iowa with highs reaching the mid 90s and apparent 
temperatures over 105F. The only caveat will be how convective 
debris affects the temperatures over southern Iowa today. 
Regardless, a heat advisory remains in effect for these areas this 
afternoon.

After the frontal passage today and tonight, temperatures return to 
normal through the week and conditions quiet down, with minimal 
precipitation in the forecast through the rest of the period. 


&&

.AVIATION /06Z TAFS THROUGH 06Z TUESDAY/...
Issued at 1205 AM CDT Mon Jul 15 2024

Fog is anticipated to develop over KMCW and KALO in the early
morning with IFR restrictions possible until sunrise.
Thunderstorms expected throughout the day, although location and
severity remains at low confidence. Have included VCTS to
reflect window of highest confidence for each site. KMCW to have
storms nearby in the morning, but confidence is low in their
sustainability as they sink into the state so left out of KALO
and KFOD for now. Secondary storms are possible for the rest of
sites in the afternoon, primarily after 20z. Will continue to
refine timing with upcoming issuances. Important to note that
storms may be severe with high winds in excess of 50kts possible
throughout the day.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ057>062-070>075-081>086-092>097.

&&

$$

DISCUSSION...Dodson
AVIATION...Jimenez
",AFDDMX,2024-07-15 04:18:00-05,KDMX,FXUS63,
"462 
FXUS63 KDMX 151124
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
624 AM CDT Mon Jul 15 2024

 ...Updated for the 12z Aviation Discussion...

.KEY MESSAGES...

- A few strong storms are possible this morning with additional
  development expected again this afternoon and into the early
  evening. Severe weather is likely with any storms that develop
  today, with damaging wind gusts the primary concern.
 
- Hot and humid temperatures continue south today, with heat
  index values over 105F possible. 

- Quieter conditions with the return of more seasonal
  temperatures through the remainder of the week.

&&

.DISCUSSION...
Issued at 414 AM CDT Mon Jul 15 2024

Our upper level ridge to the southwest remains in place early Monday 
morning but an upper trough has begun to dig south into the northern 
plains region. The resultant forcing has produced convection 
currently over eastern North Dakota/western Minnesota at the time of 
writing. This complex of storms will bring the first possibility for 
storms in the area today as the MCS makes it’s way south southeast 
through Minnesota and potentially into northern Iowa later this 
morning. The current expectation is for this to roughly follow the 
edge of the more capped air but remain rooted to the LLJ and 
associated theta-e advection wing. Therefore, if the MCS can sustain 
itself along this path, it would arrive in the far north to 
northeastern portions of the area later this morning, with damaging 
winds being the greatest concern. However, recent trends in model 
guidance have been for this complex to weaken as it nears the state, 
likely as it loses support from the LLJ in the morning and succumbs 
to the warmer air aloft. If this scenario plays out, the MCS itself 
would not be of immediate concern, but it’s remnants (whether that 
be an outflow boundary or an MCV), would be a potential point for re-
development as they pass through less capped air over northeast Iowa 
this morning. With plenty of instability present and improving wind 
fields allowing for a more favorable shear environment today, any of 
this redevelopment could become severe, with strong winds still 
being the primary area of concern. If it’s not already apparent from 
the scenarios laid out above, confidence in the morning convective 
trends is low, and it’s certainly also a possibility for the 
forecast area to remain dry through the morning hours. 

CAMs continue to struggle with how convective trends will play out 
into the afternoon as well, and it’d be nearly impossible to hone in 
on any one solution. Therefore, instead of trying to get surgical 
with saying one model run is better than another, we’ll focus on the 
features present and the potential scenarios that may result. As we 
move through the day, the trough digs further south with a surface 
boundary arriving in northern Iowa around 17 to 18z then tracking 
through the area and departing to the south in the evening around 04 
to 05z. This boundary will be the primary focal point for additional 
storm development today, especially as we progress into the 
afternoon and the warm layer aloft begins to mix out. The initial 
development will favor areas further east where temperatures aloft 
are cooler, while areas further west will rely on erosion of the 
warm layer aloft to produce storms, likely later in the day and 
further south. Guidance indicates that the boundary may also slow 
down some as it reaches southern Iowa, which could lead to brief 
periods of training storms over southern Iowa. Based on this 
expected progression, anticipating that the most favorable areas for 
storms will initially be further north and east in the early 
afternoon hours, with increasing chances slightly further west and 
in the southern portions of Iowa by late afternoon and evening. Of 
course, this is the expected scenario. Failure modes/alternate 
scenarios would include convection developing west along the nose of 
the LLJ in the morning hours and tracking east through the area, a 
faster/slower eroding cap allowing for more/less storms further 
north and west, and outflow boundaries producing convection ahead of 
the synoptic front. 

The environment available to storms out ahead of the boundary is 
quite favorable for severe weather. MLCAPE values are around 3000 to 
4000 J/kg or higher, and stronger midlevel winds ahead of the upper 
trough will allow for 0-6 km bulk shear values of 40 to 50 kts. 
Moisture will be plentiful as well, with warm, moist air pooling 
along the boundary resulting in PWATs up to 2.5” or more in some 
locations. Therefore, any storms that fire will become organized and 
have the ability to produce efficient rainfall. However, despite the 
moisture present within the profile, relatively dry conditions will 
be in place at the lower levels thanks to the abnormally warm air in 
place over the state. Therefore, DCAPE values of 1000 to 1500 J/kg 
are expected with cold pool development likely. This, in conjunction 
with the strong shear, will promote upscale growth of initially 
discrete storms as they congeal into an MCS, making damaging winds a 
strong concern for today. Storm motions will generally be to the 
east, which will be along to slightly south of the boundary 
orientation. This would suggest the possibility for cell mergers and 
ingestion of any boundaries produced by convection further east, 
which could locally amplify wind gusts within the MCS. Therefore, 
not completely out of the realm of possibility to see winds nearing 
70kts with these storms, and could potentially see some localized 
wind gusts even higher than that. That being said, with convective 
initiation favoring the eastern portions of the area and the 30 to 
35 kt storm motions, storms may depart the area prior to reaching 
peak intensity, which  echoes both the SPC and machine learning 
severe probabilities that favor the eastern portions of the area. 
Regardless, this will all depend on where storms initiate and grow 
upscale. 

In addition to strong winds, hail is possible initially with any 
discrete convection, but will  become less likely as the storm 
transitions to a linear mode. Similarly, a tornado or two cannot be 
ruled out, whether that be with a rotating discrete storm, or with 
any embedded QLCS tornadoes that may develop. The 0-3 km bulk shear 
will be borderline around 25 to 30 kts, but there will be plenty of 
stretching, so will need to monitor for mesovortex development along 
any MCSs as well. SPC has maintained the enhanced risk for severe 
weather over the eastern portions of our forecast area and into 
eastern Iowa, with a risk for significant winds over the same area. 
This all being said, want to once again stress the uncertainty in 
location and evolution of storms today and into this evening. While 
the environment is primed, there are a lot of factors that could 
influence storms today. Therefore, our recommendation is to prepare 
as if your area could see significant weather, but bear in mind that 
some may see little to no storms at all. 

Finally, not to be forgotten with the severe weather expected today, 
temperatures will once again be hot and humid, mainly over southern 
Iowa where the boundary won't reach until late in the day. With 
850mb temperatures in the upper 20s to near 30 celsius, this looks 
like it could be the warmest day of the past couple for those in the 
southern half of Iowa with highs reaching the mid 90s and apparent 
temperatures over 105F. The only caveat will be how convective 
debris affects the temperatures over southern Iowa today. 
Regardless, a heat advisory remains in effect for these areas this 
afternoon.

After the frontal passage today and tonight, temperatures return to 
normal through the week and conditions quiet down, with minimal 
precipitation in the forecast through the rest of the period.

&&

.AVIATION /12Z TAFS THROUGH 12Z TUESDAY/...
Issued at 617 AM CDT Mon Jul 15 2024

Areas of patchy fog have been resulting in low visibilities as
low as 1/4 mile in portions of the state this morning, primarily
impacting KMCW and KOTM. As has been the case the past few
mornings, fog should dissipate over the next few hours as the 
sun rises. 

Main aviation impacts today will be the chance for storms 
capable of producing severe wind gusts as they develop ahead of 
a cool front passing through the state. Confidence is quite low 
for how storms will evolve through the day, but have tried to 
time out the most likely period for seeing storms at each site. 
While storms could affect any site, it is possible that some may
be missed entirely. Regardless, wanted to have some mention of
thunder in the terminals due to the intensity of the potential
storms. Aside from the precipitation, winds will shift to more
north northwesterly behind the cool front later this evening.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory from 1 PM this afternoon to 8 PM CDT this 
evening for IAZ057>062-070>075-081>086-092>097.

&&

$$

DISCUSSION...Dodson
AVIATION...Dodson
",AFDDMX,2024-07-15 06:24:00-05,KDMX,FXUS63,
"421 
FXUS63 KDMX 151730
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1230 PM CDT Mon Jul 15 2024

 ...Updated for the 18z Aviation Discussion...

.KEY MESSAGES...

- A few strong storms are possible this morning with additional
  development expected again this afternoon and into the early
  evening. Severe weather is likely with any storms that develop
  today, with damaging wind gusts the primary concern.
 
- Hot and humid temperatures continue south today, with heat
  index values over 105F possible. 

- Quieter conditions with the return of more seasonal
  temperatures through the remainder of the week.

&&

.DISCUSSION...
Issued at 414 AM CDT Mon Jul 15 2024

Our upper level ridge to the southwest remains in place early Monday 
morning but an upper trough has begun to dig south into the northern 
plains region. The resultant forcing has produced convection 
currently over eastern North Dakota/western Minnesota at the time of 
writing. This complex of storms will bring the first possibility for 
storms in the area today as the MCS makes it’s way south southeast 
through Minnesota and potentially into northern Iowa later this 
morning. The current expectation is for this to roughly follow the 
edge of the more capped air but remain rooted to the LLJ and 
associated theta-e advection wing. Therefore, if the MCS can sustain 
itself along this path, it would arrive in the far north to 
northeastern portions of the area later this morning, with damaging 
winds being the greatest concern. However, recent trends in model 
guidance have been for this complex to weaken as it nears the state, 
likely as it loses support from the LLJ in the morning and succumbs 
to the warmer air aloft. If this scenario plays out, the MCS itself 
would not be of immediate concern, but it’s remnants (whether that 
be an outflow boundary or an MCV), would be a potential point for re-
development as they pass through less capped air over northeast Iowa 
this morning. With plenty of instability present and improving wind 
fields allowing for a more favorable shear environment today, any of 
this redevelopment could become severe, with strong winds still 
being the primary area of concern. If it’s not already apparent from 
the scenarios laid out above, confidence in the morning convective 
trends is low, and it’s certainly also a possibility for the 
forecast area to remain dry through the morning hours. 

CAMs continue to struggle with how convective trends will play out 
into the afternoon as well, and it’d be nearly impossible to hone in 
on any one solution. Therefore, instead of trying to get surgical 
with saying one model run is better than another, we’ll focus on the 
features present and the potential scenarios that may result. As we 
move through the day, the trough digs further south with a surface 
boundary arriving in northern Iowa around 17 to 18z then tracking 
through the area and departing to the south in the evening around 04 
to 05z. This boundary will be the primary focal point for additional 
storm development today, especially as we progress into the 
afternoon and the warm layer aloft begins to mix out. The initial 
development will favor areas further east where temperatures aloft 
are cooler, while areas further west will rely on erosion of the 
warm layer aloft to produce storms, likely later in the day and 
further south. Guidance indicates that the boundary may also slow 
down some as it reaches southern Iowa, which could lead to brief 
periods of training storms over southern Iowa. Based on this 
expected progression, anticipating that the most favorable areas for 
storms will initially be further north and east in the early 
afternoon hours, with increasing chances slightly further west and 
in the southern portions of Iowa by late afternoon and evening. Of 
course, this is the expected scenario. Failure modes/alternate 
scenarios would include convection developing west along the nose of 
the LLJ in the morning hours and tracking east through the area, a 
faster/slower eroding cap allowing for more/less storms further 
north and west, and outflow boundaries producing convection ahead of 
the synoptic front. 

The environment available to storms out ahead of the boundary is 
quite favorable for severe weather. MLCAPE values are around 3000 to 
4000 J/kg or higher, and stronger midlevel winds ahead of the upper 
trough will allow for 0-6 km bulk shear values of 40 to 50 kts. 
Moisture will be plentiful as well, with warm, moist air pooling 
along the boundary resulting in PWATs up to 2.5” or more in some 
locations. Therefore, any storms that fire will become organized and 
have the ability to produce efficient rainfall. However, despite the 
moisture present within the profile, relatively dry conditions will 
be in place at the lower levels thanks to the abnormally warm air in 
place over the state. Therefore, DCAPE values of 1000 to 1500 J/kg 
are expected with cold pool development likely. This, in conjunction 
with the strong shear, will promote upscale growth of initially 
discrete storms as they congeal into an MCS, making damaging winds a 
strong concern for today. Storm motions will generally be to the 
east, which will be along to slightly south of the boundary 
orientation. This would suggest the possibility for cell mergers and 
ingestion of any boundaries produced by convection further east, 
which could locally amplify wind gusts within the MCS. Therefore, 
not completely out of the realm of possibility to see winds nearing 
70kts with these storms, and could potentially see some localized 
wind gusts even higher than that. That being said, with convective 
initiation favoring the eastern portions of the area and the 30 to 
35 kt storm motions, storms may depart the area prior to reaching 
peak intensity, which  echoes both the SPC and machine learning 
severe probabilities that favor the eastern portions of the area. 
Regardless, this will all depend on where storms initiate and grow 
upscale. 

In addition to strong winds, hail is possible initially with any 
discrete convection, but will  become less likely as the storm 
transitions to a linear mode. Similarly, a tornado or two cannot be 
ruled out, whether that be with a rotating discrete storm, or with 
any embedded QLCS tornadoes that may develop. The 0-3 km bulk shear 
will be borderline around 25 to 30 kts, but there will be plenty of 
stretching, so will need to monitor for mesovortex development along 
any MCSs as well. SPC has maintained the enhanced risk for severe 
weather over the eastern portions of our forecast area and into 
eastern Iowa, with a risk for significant winds over the same area. 
This all being said, want to once again stress the uncertainty in 
location and evolution of storms today and into this evening. While 
the environment is primed, there are a lot of factors that could 
influence storms today. Therefore, our recommendation is to prepare 
as if your area could see significant weather, but bear in mind that 
some may see little to no storms at all. 

Finally, not to be forgotten with the severe weather expected today, 
temperatures will once again be hot and humid, mainly over southern 
Iowa where the boundary won't reach until late in the day. With 
850mb temperatures in the upper 20s to near 30 celsius, this looks 
like it could be the warmest day of the past couple for those in the 
southern half of Iowa with highs reaching the mid 90s and apparent 
temperatures over 105F. The only caveat will be how convective 
debris affects the temperatures over southern Iowa today. 
Regardless, a heat advisory remains in effect for these areas this 
afternoon.

After the frontal passage today and tonight, temperatures return to 
normal through the week and conditions quiet down, with minimal 
precipitation in the forecast through the rest of the period.

&&

.AVIATION /18Z TAFS THROUGH 18Z TUESDAY/...
Issued at 1230 PM CDT Mon Jul 15 2024

Highly uncertain forecast regarding convection to 00z.
Approaching H500 wave expected to break strong H700 cap between
20 and 22z. Weak wind shift continues from NW Iowa to about the
Quad Cities now, but should lift slightly north by 00z. CAMS
suggest the higher storm chance area between US20 and I80,
focusing mainly on FOD/ALO/DSM and perhaps later OTM. For now 
have not hit conditions too hard, but will update for lower
cigs/vsbys and stronger convective wind gusts once storms form.
/rev

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ057>062-
070>075-081>086-092>097.

&&

$$

DISCUSSION...Dodson
AVIATION...REV
",AFDDMX,2024-07-15 12:30:00-05,KDMX,FXUS63,
"884 
FXUS63 KDMX 151921
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
221 PM CDT Mon Jul 15 2024

.KEY MESSAGES...

- Enhanced Severe Storm Risk Through Evening with Risk of Higher
  End Damaging Winds, Some Hail and Possible Tornado
- Heat Advisory in place to this evening South
- Cooler and Mainly Dry Tuesday through Sunday

&&

.DISCUSSION...
Issued at 221 PM CDT Mon Jul 15 2024

Confidence Short Term: Medium

Warm layer aloft still holding down convection at 1815z with cu 
field showing up along one of the many weak boundaries over the 
region. The overall synoptic set up is the same with a trough of low 
pressure from northern Wisconsin back to western MN, then south to 
western Iowa. Weak lows are present in western MN and near Omaha. 
VISSAT shows the area of cu and also the same location of the 
highest SBCAPE of 6000 to 7000 J/kg and surface moisture 
convergence. Currently there remains some weak MLCIN over 
western Iowa where some convection is trying to fire. However, 
just to the east of where some storms are beginning, the area is
totally uncapped with 4000 to 4500 J/kg MLCAPE. The more 
widespread initiation is still expected between 21 to 22z. 
Though the earlier HRRR runs today have been backing off on our 
area to some degree, the latest 17z HRRR is now initiating 
convection around 20 to 21z and quickly filling in an area of 
discrete storms around US20 US30 corridor. This then grows 
upscale into northern and west central Illinois. Trailing severe
convection begins to fill in between US20 and I80 between 22z 
and 01z. So, holding on to similar thinking with the potential 
still there. While the potential for widespread high end wind 
event may be reduced slightly in this scenario, we should still 
see some pockets of significant damaging winds within the 
clusters of storms. The good news is that most of the storms 
should exit the region around 02 to 03z and the remainder of the
night relatively quiet. Tomorrow was originally expected to be 
dry, but there is another weak wave over Montana tracking 
southeast. This may bring a few showers/isolated storms to the 
region by Tuesday afternoon. The main theme for tomorrow and 
moving forward is cooler temperatures. Highs tomorrow will range
from the upper 70s north to the lower to mid 80s south. 
Tomorrow night as high pressure settles into the region, any 
lingering showers should come to an end with cooler overnight 
mins in the upper 50s to mid 60s. 

.Long Term /Wednesday through Monday/...

Confidence: Medium

Most of the week will remain dry with cooler temperatures in the 70s 
to lower 80s. Toward the weekend, we return to southerly flow with 
chances once again for some convection by late Friday night west. 
This trend will extend into the weekend, but with lower confidence 
on coverage and timing. Temperatures should remain pleasant and in 
the 70s to lower 80s. 

&&

.AVIATION /18Z TAFS THROUGH 18Z TUESDAY/...
Issued at 1230 PM CDT Mon Jul 15 2024

Highly uncertain forecast regarding convection to 00z.
Approaching H500 wave expected to break strong H700 cap between
20 and 22z. Weak wind shift continues from NW Iowa to about the
Quad Cities now, but should lift slightly north by 00z. CAMS
suggest the higher storm chance area between US20 and I80,
focusing mainly on FOD/ALO/DSM and perhaps later OTM. For now 
have not hit conditions too hard, but will update for lower
cigs/vsbys and stronger convective wind gusts once storms form.
/rev

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ057>062-
070>075-081>086-092>097.

&&

$$

DISCUSSION...REV
AVIATION...REV
",AFDDMX,2024-07-15 14:21:00-05,KDMX,FXUS63,
"666 
FXUS63 KDMX 152334
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
634 PM CDT Mon Jul 15 2024

 ...Updated for the 00z Aviation Discussion...

.KEY MESSAGES...

- Enhanced Severe Storm Risk Through Evening with Risk of Higher
  End Damaging Winds, Some Hail and Possible Tornado
- Heat Advisory in place to this evening South
- Cooler and Mainly Dry Tuesday through Sunday

&&

.DISCUSSION...
Issued at 221 PM CDT Mon Jul 15 2024

Confidence Short Term: Medium

Warm layer aloft still holding down convection at 1815z with cu 
field showing up along one of the many weak boundaries over the 
region. The overall synoptic set up is the same with a trough of low 
pressure from northern Wisconsin back to western MN, then south to 
western Iowa. Weak lows are present in western MN and near Omaha. 
VISSAT shows the area of cu and also the same location of the 
highest SBCAPE of 6000 to 7000 J/kg and surface moisture 
convergence. Currently there remains some weak MLCIN over 
western Iowa where some convection is trying to fire. However, 
just to the east of where some storms are beginning, the area is
totally uncapped with 4000 to 4500 J/kg MLCAPE. The more 
widespread initiation is still expected between 21 to 22z. 
Though the earlier HRRR runs today have been backing off on our 
area to some degree, the latest 17z HRRR is now initiating 
convection around 20 to 21z and quickly filling in an area of 
discrete storms around US20 US30 corridor. This then grows 
upscale into northern and west central Illinois. Trailing severe
convection begins to fill in between US20 and I80 between 22z 
and 01z. So, holding on to similar thinking with the potential 
still there. While the potential for widespread high end wind 
event may be reduced slightly in this scenario, we should still 
see some pockets of significant damaging winds within the 
clusters of storms. The good news is that most of the storms 
should exit the region around 02 to 03z and the remainder of the
night relatively quiet. Tomorrow was originally expected to be 
dry, but there is another weak wave over Montana tracking 
southeast. This may bring a few showers/isolated storms to the 
region by Tuesday afternoon. The main theme for tomorrow and 
moving forward is cooler temperatures. Highs tomorrow will range
from the upper 70s north to the lower to mid 80s south. 
Tomorrow night as high pressure settles into the region, any 
lingering showers should come to an end with cooler overnight 
mins in the upper 50s to mid 60s. 

.Long Term /Wednesday through Monday/...

Confidence: Medium

Most of the week will remain dry with cooler temperatures in the 70s 
to lower 80s. Toward the weekend, we return to southerly flow with 
chances once again for some convection by late Friday night west. 
This trend will extend into the weekend, but with lower confidence 
on coverage and timing. Temperatures should remain pleasant and in 
the 70s to lower 80s.

&&

.AVIATION /00Z TAFS THROUGH 00Z WEDNESDAY/...
Issued at 634 PM CDT Mon Jul 15 2024

Storms continue moving southeast of most sites, with the
exception is OTM. Will monitor storms. Have timed out arrival.
Most of the remainder is clear. Expecting VFR conditions to
follow for tonight. Some potential for scat showers tomorrow
afternoon. Will leave for 06z TAF package to handle.  /rev

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
Heat Advisory until 8 PM CDT this evening for IAZ057>062-
070>075-081>086-092>097.

&&

$$

DISCUSSION...REV
AVIATION...REV
",AFDDMX,2024-07-15 18:34:00-05,KDMX,FXUS63,
"870 
FXUS63 KDMX 160452
AFDDMX

Area Forecast Discussion
National Weather Service Des Moines IA
1152 PM CDT Mon Jul 15 2024

 ...Updated for the 06z Aviation Discussion...

.KEY MESSAGES...

- Enhanced Severe Storm Risk Through Evening with Risk of Higher
  End Damaging Winds, Some Hail and Possible Tornado
- Heat Advisory in place to this evening South
- Cooler and Mainly Dry Tuesday through Sunday

&&

.DISCUSSION...
Issued at 221 PM CDT Mon Jul 15 2024

Confidence Short Term: Medium

Warm layer aloft still holding down convection at 1815z with cu 
field showing up along one of the many weak boundaries over the 
region. The overall synoptic set up is the same with a trough of low 
pressure from northern Wisconsin back to western MN, then south to 
western Iowa. Weak lows are present in western MN and near Omaha. 
VISSAT shows the area of cu and also the same location of the 
highest SBCAPE of 6000 to 7000 J/kg and surface moisture 
convergence. Currently there remains some weak MLCIN over 
western Iowa where some convection is trying to fire. However, 
just to the east of where some storms are beginning, the area is
totally uncapped with 4000 to 4500 J/kg MLCAPE. The more 
widespread initiation is still expected between 21 to 22z. 
Though the earlier HRRR runs today have been backing off on our 
area to some degree, the latest 17z HRRR is now initiating 
convection around 20 to 21z and quickly filling in an area of 
discrete storms around US20 US30 corridor. This then grows 
upscale into northern and west central Illinois. Trailing severe
convection begins to fill in between US20 and I80 between 22z 
and 01z. So, holding on to similar thinking with the potential 
still there. While the potential for widespread high end wind 
event may be reduced slightly in this scenario, we should still 
see some pockets of significant damaging winds within the 
clusters of storms. The good news is that most of the storms 
should exit the region around 02 to 03z and the remainder of the
night relatively quiet. Tomorrow was originally expected to be 
dry, but there is another weak wave over Montana tracking 
southeast. This may bring a few showers/isolated storms to the 
region by Tuesday afternoon. The main theme for tomorrow and 
moving forward is cooler temperatures. Highs tomorrow will range
from the upper 70s north to the lower to mid 80s south. 
Tomorrow night as high pressure settles into the region, any 
lingering showers should come to an end with cooler overnight 
mins in the upper 50s to mid 60s. 

.Long Term /Wednesday through Monday/...

Confidence: Medium

Most of the week will remain dry with cooler temperatures in the 70s 
to lower 80s. Toward the weekend, we return to southerly flow with 
chances once again for some convection by late Friday night west. 
This trend will extend into the weekend, but with lower confidence 
on coverage and timing. Temperatures should remain pleasant and in 
the 70s to lower 80s.

&&

.AVIATION /06Z TAFS THROUGH 06Z WEDNESDAY/...
Issued at 1149 PM CDT Mon Jul 15 2024

VFR conditions to prevail through much of the period. Fog may
redevelop across the north. Have added mention to KALO to
reflect this although coverage appears patchy.

&&

.DMX WATCHES/WARNINGS/ADVISORIES...
None.

&&

$$

DISCUSSION...REV
AVIATION...Jimenez
",AFDDMX,2024-07-15 23:52:00-05,KDMX,FXUS63,
\.
